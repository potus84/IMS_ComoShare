<?php 
	include_once '../config.php';

	$edit_order_id = $_POST['edit_order_id'];
	$edit_order_tranID = $_POST['edit_order_tranID'];
	$edit_order_productID = $_POST['edit_order_productID'];
	$edit_order_soluong = $_POST['edit_order_soluong'];
	$edit_order_gia = $_POST['edit_order_gia'];
	$edit_order_tongtien = $_POST['edit_order_tongtien'];
	$edit_order_trangthai = $_POST['edit_order_trangthai'];

	
	$ID = $_POST['id_to_edit'];
	
	try {
		$stmt = $conn->prepare("UPDATE order_product 
								SET id=:edit_order_id, 
									transaction_id=:edit_order_tranID, 
									product_id=:edit_order_productID, 
									soluong=:edit_order_soluong, 
									gia=:edit_order_gia, 
									tongtien=:edit_order_tongtien, 
									trangthai=:edit_order_trangthai
								WHERE id=:ID");
		$stmt->bindParam(':edit_order_id', $edit_order_id);
		$stmt->bindParam(':edit_order_tranID', $edit_order_tranID);
		$stmt->bindParam(':edit_order_productID', $edit_order_productID);
		$stmt->bindParam(':edit_order_soluong', $edit_order_soluong);
		$stmt->bindParam(':edit_order_gia', $edit_order_gia);
		$stmt->bindParam(':edit_order_tongtien', $edit_order_tongtien);
		$stmt->bindParam(':edit_order_trangthai', $edit_order_trangthai);
		$stmt->bindParam(':ID', $ID);
		$stmt->execute();
	}
	catch (PDOException $e) {
		echo $e->getMessage();
		exit();
	}
	
?>