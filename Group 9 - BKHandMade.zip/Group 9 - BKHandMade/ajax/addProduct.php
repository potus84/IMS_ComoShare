<?php 
	include_once '../config.php';

	try {
		$add_product = $conn->prepare("INSERT INTO product(catalog_id, name, gia, mota, giamgia, link_anh, date_added, quantity) VALUES (:catalog_id, :name, :gia, :mota, :giamgia, :link_anh, :date_added, :quantity)");

		$add_product->bindParam(':catalog_id', $_POST['add_product_category']);
		$add_product->bindParam(':name', $_POST['add_product_name']);
		$add_product->bindParam(':gia', $_POST['add_product_gia']);
		$add_product->bindParam(':mota', $_POST['add_product_mota']);
		$add_product->bindParam(':giamgia', $_POST['add_product_km']);
		$add_product->bindParam(':link_anh', $_POST['add_product_img']);
		$add_product->bindParam(':date_added', date("Y-m-d h:i:sa"));
		$add_product->bindParam(':quantity', $_POST['add_product_quant']);

		$add_product->execute();
	}
	catch (PDOException $e) {
		echo "ERROR! Co loi xay ra voi PDO";
		echo $e->getMessage();
		exit();
	}	
?>