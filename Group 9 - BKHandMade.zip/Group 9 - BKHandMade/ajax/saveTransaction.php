<?php 
	include_once '../config.php';

	$edit_id = $_POST['edit_id'];
	$edit_trangthai = $_POST['edit_trangthai'];
	$edit_cus_id = $_POST['edit_cus_id'];
	$edit_cus_name = $_POST['edit_cus_name'];
	$edit_cus_phone = $_POST['edit_cus_phone'];
	$edit_cus_email = $_POST['edit_cus_email'];
	$edit_cus_addr = $_POST['edit_cus_addr'];
	$edit_amount = $_POST['edit_amount'];
	$edit_dated = $_POST['edit_dated'];

	
	$ID = $_POST['id_to_edit'];
	
	try {
		$stmt = $conn->prepare("UPDATE transaction 
								SET id=:edit_id, 
									trangthai=:edit_trangthai, 
									customer_id=:edit_cus_id, 
									customer_name=:edit_cus_name, 
									customer_phone=:edit_cus_phone, 
									customer_email=:edit_cus_email, 
									customer_address=:edit_cus_addr, 
									amount=:edit_amount, 
									date_added=:edit_dated 
								WHERE id=:ID");
		$stmt->bindParam(':edit_id', $edit_id);
		$stmt->bindParam(':edit_trangthai', $edit_trangthai);
		$stmt->bindParam(':edit_cus_id', $edit_cus_id);
		$stmt->bindParam(':edit_cus_name', $edit_cus_name);
		$stmt->bindParam(':edit_cus_phone', $edit_cus_phone);
		$stmt->bindParam(':edit_cus_email', $edit_cus_email);
		$stmt->bindParam(':edit_cus_addr', $edit_cus_addr);
		$stmt->bindParam(':edit_amount', $edit_amount);
		$stmt->bindParam(':edit_dated', $edit_dated);
		$stmt->bindParam(':ID', $ID);
		$stmt->execute();
	}
	catch (PDOException $e) {
		echo $e->getMessage();
		exit();
	}
	
?>