<?php 
	include_once '../config.php';

	$edit_product_name = $_POST['edit_product_name'];
	$edit_product_gia = $_POST['edit_product_gia'];
	$edit_product_km = $_POST['edit_product_km'];
	$edit_product_mota = $_POST['edit_product_mota'];
	$edit_product_quant = $_POST['edit_product_quant'];
	$edit_product_category = $_POST['edit_product_category'];
	$edit_product_img = $_POST['edit_product_img'];

	
	$ID = $_POST['id_to_edit'];
	
	try {
		$stmt = $conn->prepare("UPDATE product 
								SET name=:edit_product_name, 
									gia=:edit_product_gia, 
									giamgia=:edit_product_km, 
									mota=:edit_product_mota, 
									link_anh=:edit_product_img, 
									catalog_id=:edit_product_category, 
									quantity=:edit_product_quant
								WHERE id=:ID");
		$stmt->bindParam(':edit_product_name', $edit_product_name);
		$stmt->bindParam(':edit_product_gia', $edit_product_gia);
		$stmt->bindParam(':edit_product_km', $edit_product_km);
		$stmt->bindParam(':edit_product_mota', $edit_product_mota);
		$stmt->bindParam(':edit_product_img', $edit_product_img);
		$stmt->bindParam(':edit_product_category', $edit_product_category);
		$stmt->bindParam(':edit_product_quant', $edit_product_quant);
		$stmt->bindParam(':ID', $ID);
		$stmt->execute();
	}
	catch (PDOException $e) {
		echo $e->getMessage();
		exit();
	}
	
?>