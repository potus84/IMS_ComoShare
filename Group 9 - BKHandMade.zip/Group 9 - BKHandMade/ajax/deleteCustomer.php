<?php 
	if (isset($_POST['id'])) {
		include_once '../config.php';
		$id = $_POST['id'];
		try {
			$conn->exec("DELETE FROM customer WHERE id = '$id'");
		}
		catch (PDOException $e) {
			echo $e->getMessage();
			exit();
		}
	}
?>