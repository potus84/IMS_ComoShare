<?php 
	$cart_id = $_POST['cart_id'];
	$num = $_POST['num'];

	include_once '../config.php';

	try {
		$stmt = $conn->prepare("UPDATE cart 
								SET soluong=:num 
								WHERE cart_id=:cart_id");
		$stmt->bindParam(':num', $num);
		$stmt->bindParam(':cart_id', $cart_id);
		$stmt->execute();
	}
	catch (PDOException $e) {
		echo "ERROR! Co loi xay ra voi PDO";
		echo $e->getMessage();
		exit();
	}	
?>