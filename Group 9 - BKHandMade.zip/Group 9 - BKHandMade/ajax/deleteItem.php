<?php 
	if (isset($_POST['cart_id'])) {
		include_once '../config.php';
		$cart_id = $_POST['cart_id'];
		try {
			$conn->exec("DELETE FROM cart WHERE cart_id = '$cart_id'");
		}
		catch (PDOException $e) {
			echo $e->getMessage();
			exit();
		}
	}
?>