<?php 
	if (isset($_POST['id'])) {
		include_once '../config.php';
		$id = $_POST['id'];
		try {
			$stmt = $conn->prepare("SELECT * FROM transaction WHERE id = '$id'");
			$stmt->setFetchMode(PDO::FETCH_ASSOC);
    		$stmt->execute();

    		$response = array();

    		while($row = $stmt->fetch()) {
    			$response = $row;
    		}
    		echo json_encode($response);
		}
		catch (PDOException $e) {
			echo $e->getMessage();
			exit();
		}
	}
?>