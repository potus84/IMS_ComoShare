
<?php 
	$host = 'localhost';
	$database = 'ltweb';
	$username = 'root';
	$password = '';

	try {
		$conn = new PDO('mysql:host=' . $host . ';dbname=' . $database, $username, $password);	
	}
	catch (PDOException $e) {
		echo "ERROR! Co loi xay ra voi PDO";
		echo $e->getMessage();
		exit();
	}		
?>