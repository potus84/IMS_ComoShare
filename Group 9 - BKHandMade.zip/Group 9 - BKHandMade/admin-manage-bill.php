<?php 
	include_once 'config.php';
	session_start();
	if (!isset($_SESSION['admin'])) {
		header('Location: admin-log.php');
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>Admin Manage Bill</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="Hover-master/css/hover.css">
    <link rel="stylesheet" href="DataTables-1.10.12/media/css/dataTables.bootstrap.css">
    <!-- <link rel="stylesheet" href="bootstrap-material-design-master/dist/css/bootstrap-material-design.min.css"> -->

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/admin-manage.css">
    <link rel="stylesheet" href="css/admin-manage-bill.css">


  </head>

  <body>
	<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="admin.php">Admin Site</a>
			</div>
	
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Xin chào <?php echo $_SESSION['admin'] ?><b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><form method="POST">
								<button type="submit" name="logout-btn" class="btn btn-link">Đăng xuất</button>
							</form></li>
						</ul>
					</li>
				</ul>
			</div><!-- /.navbar-collapse -->
		</div>
	</nav>
	<!-- /navbar -->
	<?php 
		if (isset($_POST['logout-btn'])) {
			unset($_SESSION['admin']);
			echo "<script>window.location.replace('admin-log.php');</script>";
		}
	?>


	<div class="wrapper container-fluid">
		<div class="sidebar col-sm-3 col-md-2">
			<ul>
				<li><a href="admin-manage-admin.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý admin</a>
        		</li>
				<li><a href="admin-manage-member.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý thành viên</a>
				</li>
				<li><a href="admin-manage-product.php"><span><i class="fa fa-briefcase" aria-hidden="true"></i></span>Quản lý sản phẩm</a></li>
				<li><a href="admin-manage-bill.php"><span><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>Quản lý đơn hàng</a></li>
			</ul>
		</div>
		<!-- /sidebar -->
		<div class="content manage-product manage-bill col-sm-9 col-md-10">
			<h1 class="text-center">QUẢN LÝ GIAO DỊCH </h1>
			
			<div class="modal fade" id="modal-id">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h2 class="modal-title">Thêm đơn hàng</h2>
						</div>
						<div class="modal-body">
							<form action="" method="POST" role="form">
								<div class="form-group">									
									<div class="input-field">
										<input type="text" class="form-control" id="" placeholder="Tên khách hàng" required>
									</div>
									<div class="input-field">
										<input type="text" class="form-control" id="" placeholder="SĐT" required>
									</div>
									<div class="input-field">
										<input type="text" class="form-control" id="" placeholder="Sản phẩm" required>
									</div>	
									<div class="input-field">
										<input type="text" class="form-control" id="input-price" placeholder="Giá" required onchange="money()">
									</div>
									<div class="input-field">
										<input type="text" class="form-control" id="input-number" placeholder="Số lượng" required onchange="money()">
									</div>
									<div class="input-field">
										<textarea class="form-control" rows="5" required placeholder="Nơi giao hàng"></textarea>
									</div>
									<div class="input-field">
										<label for="">Tình trạng</label>
										<select name="" id="input" class="form-control" required>
											<option value="">Chưa giao hàng</option>
											<option value="">Đã giao hàng</option>
										</select>
									</div>
									<div class="input-field input-money">
										<label for="">Thành tiền: </label><span id="to-money">0 VNĐ</span>
									</div>
									<div class="form-footer">
										<button type="button" class="btn btn-cancle-form" data-dismiss="modal">Hủy</button>
										<button type="submit" class="btn btn-save-form">Tạo</button>
									</div>
								</div>	
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /modal-create -->


			<div class="modal fade modal-modified" id="modal-edit-transaction">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h2 class="modal-title">Chỉnh sửa giao dịch</h2>
						</div>
						<div class="modal-body">
							<form method="POST" role="form">
								<div class="form-group">									
									<div class="input-field">
										<label>ID</label>
										<input type="text" class="form-control" id="edit_transaction_id" placeholder="ID" required>
									</div>
									<div class="input-field">
										<label>Trạng thái</label>
										<input type="text" class="form-control" id="edit_transaction_trangthai" placeholder="Trạng thái" required>
									</div>
									<div class="input-field">
										<label>Customer ID</label>
										<input type="text" class="form-control" id="edit_transaction_cus_id" placeholder="Customer ID" required>
									</div>	
									<div class="input-field">
										<label>Customer Name</label>
										<input type="text" class="form-control" id="edit_transaction_cus_name" placeholder="Customer Name" required>
									</div>
									<div class="input-field">
										<label>Customer Phone</label>
										<input type="text" class="form-control" id="edit_transaction_cus_phone" placeholder="Customer Phone" required>
									</div>
									<div class="input-field">
										<label>Customer Email</label>
										<input type="text" class="form-control" id="edit_transaction_cus_email" placeholder="Customer Email" required>
									</div>
									<div class="input-field">
										<label>Customer Address</label>
										<textarea name="address" class="form-control" id="edit_transaction_cus_addr" placeholder="Customer Address" rows="3" required></textarea>
									</div>
									<div class="input-field">
										<label>Amount</label>
										<input type="text" class="form-control" id="edit_transaction_amount" placeholder="Amount" required>
									</div>
									<div class="input-field">
										<label>Date added</label>
										<input type="text" class="form-control" id="edit_transaction_dated" placeholder="Date added" required>
									</div>
									<input type="hidden" id="tranID">
									<div class="form-footer">
										<button type="button" class="btn btn-cancle-form" data-dismiss="modal">Hủy</button>
										<button type="submit" class="btn btn-save-form" onclick="saveTransaction()">Lưu</button>
									</div>
								</div>	
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /modal-modified-transaction -->

			<div class="modal fade modal-modified" id="modal-edit-order">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h2 class="modal-title">Chỉnh sửa đơn hàng</h2>
						</div>
						<div class="modal-body">
							<form method="POST" role="form">
								<div class="form-group">									
									<div class="input-field">
										<label>ID</label>
										<input type="text" class="form-control" id="edit_order_id" placeholder="ID" required>
									</div>
									<div class="input-field">
										<label>Transaction ID</label>
										<input type="text" class="form-control" id="edit_order_tranID" placeholder="Transaction ID" required>
									</div>
									<div class="input-field">
										<label>Product ID</label>
										<input type="text" class="form-control" id="edit_order_productID" placeholder="Product ID" required>
									</div>	
									<div class="input-field">
										<label>Số lượng</label>
										<input type="text" class="form-control" id="edit_order_soluong" placeholder="Số lượng" required>
									</div>
									<div class="input-field">
										<label>Giá</label>
										<input type="text" class="form-control" id="edit_order_gia" placeholder="Giá" required>
									</div>
									<div class="input-field">
										<label>Tổng tiền</label>
										<input type="text" class="form-control" id="edit_order_tongtien" placeholder="Tổng tiền" required>
									</div>
									<div class="input-field">
										<label>Trạng thái</label>
										<input type="text" class="form-control" id="edit_order_trangthai" placeholder="Trạng thái" required>
									</div>

									<input type="hidden" id="OrderID">
									<div class="form-footer">
										<button type="button" class="btn btn-cancle-form" data-dismiss="modal">Hủy</button>
										<button type="submit" class="btn btn-save-form" onclick="saveOrder()">Lưu</button>
									</div>
								</div>	
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /modal-modified-transaction -->

			<div class="modal fade modal-delete" id="modal-id">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h2 class="modal-title">Xóa đơn hàng</h2>
						</div>
						<div class="modal-body">
							<h3>Bạn có chắc chắn muốn xóa đơn hàng này?</h3>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-save-form" data-dismiss="modal">Không</button>
							<button type="submit" class="btn btn-cancle-form">Có</button>
						</div>
					</div>
				</div>
			</div>
			<!-- /modal-delete -->


			<h1>Danh sách giao dịch</h1>
			<!-- <a class="btn btn-add-member" data-toggle="modal" href='#modal-id'>Thêm giao dịch</a> -->
			<table class="list-bill display transaction" cellspacing="0" width="100%">
				<thead>
					<tr>
						<td>ID</td>
						<td>Trạng thái</td>
						<td>Customer ID</td>
						<td>Customer Name</td>
						<td>Customer Phone</td>
						<td>Customer Email</td>
						<td>Customer Address</td>
						<td>Amount</td>
						<td>Date added</td>
						<td>Sửa</td>
						<td>Xóa</td>
					</tr>
				</thead>
				<tbody>
				<?php 
					try {
						$stmt_transaction = $conn->prepare("SELECT * FROM transaction");	
						$stmt_transaction->setFetchMode(PDO::FETCH_ASSOC);
						$stmt_transaction->execute();
						while ($row = $stmt_transaction->fetch()) {
							$transaction_row = "<tr>";
							$transaction_row .= "<td>" . $row['id'] . "</td>";
							$transaction_row .= "<td>" . $row['trangthai'] . "</td>";
							$transaction_row .= "<td>" . $row['customer_id'] . "</td>";
							$transaction_row .= "<td>" . $row['customer_name'] . "</td>";
							$transaction_row .= "<td>" . $row['customer_phone'] . "</td>";
							$transaction_row .= "<td>" . $row['customer_email'] . "</td>";
							$transaction_row .= "<td>" . $row['customer_address'] . "</td>";
							$transaction_row .= "<td>" . $row['amount'] . "</td>";
							$transaction_row .= "<td>" . $row['date_added'] . "</td>";
							$transaction_row .= "<td><button type='button' class='btn btn-warning' onclick='editTransaction(" .$row['id']. ")'>Edit</button></td>";
							$transaction_row .=  "<td><button type='button' class='btn btn-danger' onclick='deleteTransaction(" .$row['id']. ")'>Delete</button></td>";
							$transaction_row .= "</tr>";
							echo $transaction_row;
						}
					}
					catch (PDOException $e) {
						echo "ERROR! Co loi xay ra voi PDO";
						echo $e->getMessage();
						exit();
					}
				?>	
				</tbody>
				
			</table>
			<!-- /transaction -->


			<h1>Danh sách đơn hàng</h1>
			<!-- <a class="btn btn-add-member" data-toggle="modal" href='#modal-id'>Thêm đơn hàng</a> -->
			<table class="list-bill bill">
				<thead>
					<tr>
						<td>ID</td>
						<td>Transaction ID</td>
						<td>Product ID</td>
						<td>Số lượng</td>
						<td>Giá</td>
						<td>Tổng tiền</td>
						<td>Trạng thái</td>
						<td>Sửa</td>
						<td>Xóa</td>
					</tr>
				</thead>
				<tbody>
					<?php 
					try {
						$stmt_transaction = $conn->prepare("SELECT * FROM order_product");	
						$stmt_transaction->setFetchMode(PDO::FETCH_ASSOC);
						$stmt_transaction->execute();
						while ($row = $stmt_transaction->fetch()) {
							$transaction_row = "<tr>";
							$transaction_row .= "<td>" . $row['id'] . "</td>";
							$transaction_row .= "<td>" . $row['transaction_id'] . "</td>";
							$transaction_row .= "<td>" . $row['product_id'] . "</td>";
							$transaction_row .= "<td>" . $row['soluong'] . "</td>";
							$transaction_row .= "<td>" . $row['gia'] . "</td>";
							$transaction_row .= "<td>" . $row['tongtien'] . "</td>";
							$transaction_row .= "<td>" . $row['trangthai'] . "</td>";
							$transaction_row .= "<td><button type='button' class='btn btn-warning' onclick='editOrder(" .$row['id']. ")'>Edit</button></td>";
							$transaction_row .=  "<td><button type='button' class='btn btn-danger' onclick='deleteOrder(" .$row['id']. ")'>Delete</button></td>";
							$transaction_row .= "</tr>";
							echo $transaction_row;
						}
					}
					catch (PDOException $e) {
						echo "ERROR! Co loi xay ra voi PDO";
						echo $e->getMessage();
						exit();
					}
				?>	
				</tbody>
				
			</table>
			<!-- /order -->

		</div>

		<!-- /content -->

	</div>
	<!-- /wrapper -->
	
	<div class="footer container-fluid">
		<p>&copy; 2016 by HCMUT</p>
	</div>
	<!-- /footer -->

	<!-- Script -->
    <!-- <script src="jquery-3.1.0.min.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="DataTables-1.10.12/media/js/jquery.dataTables.js"></script>
    <!-- <script src="bootstrap-material-design-master/dist/js/material.min.js"></script> -->
    <script>
    	$(document).ready(function() {
		    $('.list-bill').DataTable({
		    	"scrollX": true
		    });
		} );

		function editTransaction(id) {
			$('#tranID').val(id);
			$.post(
		        'ajax/editTransaction.php',
		        {
		            id: id
		        },
		        function (data, status) {
		            var transaction = JSON.parse(data);
		            
		            $("#edit_transaction_id").val(transaction.id);
		            $("#edit_transaction_trangthai").val(transaction.trangthai);
		            $("#edit_transaction_cus_id").val(transaction.customer_id);
		            $("#edit_transaction_cus_name").val(transaction.customer_name);
		            $("#edit_transaction_cus_phone").val(transaction.customer_phone);
		            $("#edit_transaction_cus_email").val(transaction.customer_email);
		            $("#edit_transaction_cus_addr").val(transaction.customer_address);
		            $("#edit_transaction_amount").val(transaction.amount);
		            $("#edit_transaction_dated").val(transaction.date_added);
		        }
		    );
		    $("#modal-edit-transaction").modal("show");
		}

		function saveTransaction() {
			var id_to_edit = $('#tranID').val();
			var id = $("#edit_transaction_id").val();
            var trangthai = $("#edit_transaction_trangthai").val();
            var cus_id = $("#edit_transaction_cus_id").val();
            var cus_name = $("#edit_transaction_cus_name").val();
            var cus_phone = $("#edit_transaction_cus_phone").val();
            var cus_email = $("#edit_transaction_cus_email").val();
            var cus_addr = $("#edit_transaction_cus_addr").val();
            var amount = $("#edit_transaction_amount").val();
            var dated = $("#edit_transaction_dated").val();
		  
		    $.post(
		        'ajax/saveTransaction.php',
		        {
		            id_to_edit: id_to_edit,
		            edit_id: id,
		            edit_trangthai: trangthai,
		            edit_cus_id: cus_id,
		            edit_cus_name: cus_name,
		            edit_cus_phone: cus_phone,
		            edit_cus_email: cus_email,
		            edit_cus_addr: cus_addr,
		            edit_amount: amount,
		            edit_dated: dated
		        },
		        function (data, status) {
		            if (data != '') {
		                alert(data);
		            }
		            else {
		                $("#modal-edit-transaction").modal("hide");
		                location.reload();
		            }
		        });
		}

		function deleteTransaction(id) {
			var x = confirm('Bạn có chắc chắn muốn xóa transaction này?');
		    if (x == true) {
		        $.post(
		            'ajax/deleteTransaction.php',
		            {
		                id: id
		            },
		            function(data, status) {
		                location.reload();
		            }
		        );
		    }
		}
		// /transaction

		function editOrder(id) {
			$('#OrderID').val(id);
			$.post(
		        'ajax/editOrder.php',
		        {
		            id: id
		        },
		        function (data, status) {
		            var order = JSON.parse(data);
		            
		            $("#edit_order_id").val(order.id);
		            $("#edit_order_tranID").val(order.transaction_id);
		            $("#edit_order_productID").val(order.product_id);
		            $("#edit_order_soluong").val(order.soluong);
		            $("#edit_order_gia").val(order.gia);
		            $("#edit_order_tongtien").val(order.tongtien);
		            $("#edit_order_trangthai").val(order.trangthai);
		        }
		    );
		    $("#modal-edit-order").modal("show");
		}

		function saveOrder() {
			var id_to_edit = $('#OrderID').val();
			var edit_order_id = $("#edit_order_id").val();
            var edit_order_tranID = $("#edit_order_tranID").val();
            var edit_order_productID = $("#edit_order_productID").val();
            var edit_order_soluong = $("#edit_order_soluong").val();
            var edit_order_gia = $("#edit_order_gia").val();
            var edit_order_tongtien = $("#edit_order_tongtien").val();
            var edit_order_trangthai = $("#edit_order_trangthai").val();
		  
		    $.post(
		        'ajax/saveOrder.php',
		        {
		            id_to_edit: id_to_edit,
		            edit_order_id: edit_order_id,
		            edit_order_tranID: edit_order_tranID,
		            edit_order_productID: edit_order_productID,
		            edit_order_soluong: edit_order_soluong,
		            edit_order_gia: edit_order_gia,
		            edit_order_tongtien: edit_order_tongtien,
		            edit_order_trangthai: edit_order_trangthai
		        },
		        function (data, status) {
		            if (data != '') {
		                alert(data);
		            }
		            else {
		                $("#modal-edit-order").modal("hide");
		                location.reload();
		            }
		        });
		}

		function deleteOrder(id) {
			var x = confirm('Bạn có chắc chắn muốn xóa transaction này?');
		    if (x == true) {
		        $.post(
		            'ajax/deleteOrder.php',
		            {
		                id: id
		            },
		            function(data, status) {
		                location.reload();
		            }
		        );
		    }
		}
		// /order
    </script>
    
  </body>
</html>







