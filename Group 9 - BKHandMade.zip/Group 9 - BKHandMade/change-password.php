<?php 
  include_once 'config.php';
  session_start();
?>

<?php 
  if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>Đổi Mật Khẩu</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="Swiper-3.3.1/dist/css/swiper.min.css">

    <link rel="stylesheet" href="css/index.css">
   
    <script src="js/jquery-3.1.0.min.js"></script>
   
  </head>

  <body>
  
  	<?php 
      include('header.php');
    ?>
    <!-- /header -->
    <div class="menu-wrap container-fluid">
      <nav class="menu clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php">Liên Hệ</a></li>
          </ul>
</nav>
      <a href="index.php" class="toggle-menu"><i class="fa fa-bars" aria-hidden="true"></i></a>
      <nav class="menu-mobile clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php">Liên Hệ</a></li>
          </ul>
      </nav>
    </div>

	<!-- content-here -->
	<div class="content container">
    
      <div class="col-sm-4 col-sm-offset-4 col-xs-8 col-xs-offset-2">
        
        <?php 
          if (isset($_POST['submit'])) {
            $old_password = $_POST['old-password'];
            $new_password = $_POST['new-password'];
            $new_password_confirm = $_POST['new-password-confirm'];

            $error = '';
            $id = $_SESSION['user_id'];
            $check_password = $conn->prepare("SELECT password FROM customer WHERE id='$id'");
            $check_password->setFetchMode(PDO::FETCH_ASSOC);
            $check_password->execute();
            $result = $check_password->fetch();

            if (md5($old_password) != $result['password']) {
              $error .= "<li>Sai password</li>";
            }

            if (strlen($new_password) < 6) {
              $error .= "<li>Password phải chứa tối thiểu 6 ký tự</li>";
            }

            if ($new_password != $new_password_confirm) {
              $error .= "<li>Nhập lại password không đúng</li>";
            }

            if ($error != '') {
              echo "<div class='alert alert-danger'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <strong>Có lỗi xảy ra!</strong>
                    <ul>" .$error. "</ul>
                  </div>";
            }
            else {
              $change_password = $conn->prepare("UPDATE customer SET password=:password WHERE id='$id'");
              $change_password->bindParam(':password', md5($new_password));
              $change_password->execute();
              echo "<script>
                      var x = confirm('Bạn đã đổi mật khẩu thành công!');
                      window.location.replace('index.php');
              </script>";
            }
            
          }
        ?>

        <form method="POST" class="form-horizontal" role="form">
            <div class="form-group">
              <legend>Đổi mật khẩu</legend>
            </div>
        
            <div class="form-group">
                <label for="">Mật khẩu cũ</label>
                <input type="password" name="old-password" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="">Mật khẩu mới</label>
                <input type="password" name="new-password" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="">Nhập lại mật khẩu mới</label>
                <input type="password" name="new-password-confirm" class="form-control" required>
            </div>
        
            <div class="form-group text-right">
                <button type="submit" name="submit" class="btn btn-primary">Lưu</button>
            </div>
        </form>
      </div>
    
	</div>
	<!-- /content -->
  



	<?php 
    include('footer.php');
  ?>

	<!-- Script -->

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="Swiper-3.3.1/dist/js/swiper.min.js"></script>

    <script src="js/main.js"></script>
    
    
    <script>
      $(".toggle-menu").click(function(){
        $(".menu-mobile").toggle();
      });

      var swiper = new Swiper('.swiper-container', {
          pagination: '.swiper-pagination',
          nextButton: '.swiper-button-next',
          prevButton: '.swiper-button-prev',
          paginationClickable: true,
          spaceBetween: 30,
          centeredSlides: true,
          autoplay: 2500,
          loop: true,
          autoplayDisableOnInteraction: false
      });

      $("a[href='#top']").click(function() {
         $("html, body").animate({ scrollTop: 0 }, "slow");
         return false;
      });

      $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#go-top').fadeIn();
        } else {
            $('#go-top').fadeOut();
        }
      });
    </script>

   
    <script type="text/javascript">
      $(function() 
      {
    //----- OPEN
    $('[data-popup-open]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
 
        e.preventDefault();
      });
 
    //----- CLOSE
    $('[data-popup-close]').on('click', function(e)  
      {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
 
        e.preventDefault();
      });
    });
      $(document).mouseup(function (e) 
      {
        if ($('.popup').is(e.target))
            {
               $(".popup").fadeOut(350);
           }
      });
     </script>
  </body>
</html>







