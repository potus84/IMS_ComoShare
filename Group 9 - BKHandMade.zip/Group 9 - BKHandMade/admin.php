<?php 
	session_start();

	if (!isset($_SESSION['admin'])) {
		header('Location: admin-log.php');
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>Admin Page</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="Swiper-3.3.1/dist/css/swiper.min.css">

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/admin.css">


  </head>

  <body>
	<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">HANDMADE BK SHOP</a>
			</div>
	
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Xin chào <?php echo $_SESSION['admin'] ?><b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><form method="POST">
								<button type="submit" name="logout-btn" class="btn btn-link">Đăng xuất</button>
							</form></li>
						</ul>
					</li>
				</ul>
			</div><!-- /.navbar-collapse -->
		</div>
	</nav>
	<!-- /navbar -->
	<?php 
		if (isset($_POST['logout-btn'])) {
			unset($_SESSION['admin']);
			echo "<script>window.location.replace('admin-log.php');</script>";
		}
	?>


	<div class="wrapper container-fluid">
		<div class="sidebar col-sm-3 col-md-2">
			<ul>
				<li><a href="admin-manage-member.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý admin</a>
				</li>
				<li><a href="admin-manage-member.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý thành viên</a>
				</li>
				<li><a href="admin-manage-product.php"><span><i class="fa fa-briefcase" aria-hidden="true"></i></span>Quản lý sản phẩm</a></li>
				<li><a href="admin-manage-bill.php"><span><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>Quản lý đơn hàng</a></li>
			</ul>
		</div>
		<!-- /sidebar -->
		<div class="content col-sm-9 col-md-10">
			<div class="jumbotron">
				<div class="container">
					<h1>Xin chào, <?php echo $_SESSION['admin'] ?></h1>
					<p>Chào mừng đến với shop!</p>
				</div>
			</div>
		</div>
		<!-- /content -->
	</div>
	<!-- /content -->
	
	<div class="footer container-fluid">
		<p>&copy; 2016 by HCMUT</p>
	</div>
	<!-- /footer -->

	<!-- Script -->
    <!-- <script src="jquery-3.1.0.min.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="Swiper-3.3.1/dist/js/swiper.min.js"></script>
    <script src="js/main.js"></script>
    
    
  </body>
</html>







