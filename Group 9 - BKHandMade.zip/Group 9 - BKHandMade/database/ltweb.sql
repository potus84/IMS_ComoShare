-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2016 at 04:53 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ltweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(3, 'quangphap', '5f4bd3a731ee62857181f6942c81e71f'),
(7, 'lxnha', 'e10adc3949ba59abbe56e057f20f883e'),
(4, 'booboo', 'af089cedf4fb105aca50a170c2b545de'),
(5, 'yenyen', '7eaa272f4bbe0ac489f4a6019177a843');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `soluong` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `customer_id`, `product_id`, `date_added`, `soluong`) VALUES
(14, 1, 64, '2016-11-27 04:51:35', 1),
(11, 1, 40, '2016-11-27 04:48:59', 1),
(12, 1, 33, '2016-11-27 04:49:40', 1),
(13, 1, 36, '2016-11-27 04:50:12', 3);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `parent`) VALUES
(6, 'DÃ¢y Chuyá»n', 2),
(5, 'Thiá»‡p', 1),
(4, 'Há»™p QuÃ ', 1),
(3, 'Khuyáº¿n MÃ£i', NULL),
(1, 'QuÃ  HandMade', NULL),
(2, 'Phá»¥ Kiá»‡n HandMade', NULL),
(7, 'VÃ²ng Tay', 2),
(8, 'Äá»“ng Há»“', 2),
(9, 'MÃ³c KhÃ³a', 2);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `email`, `password`) VALUES
(1, 'lxnha@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(2, 'xuannhak13@gmail.com', 'c1239d5a9165ca3b0f235d94687b0276');

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `transaction_id` int(255) NOT NULL,
  `id` int(255) NOT NULL,
  `product_id` int(255) NOT NULL,
  `soluong` int(11) NOT NULL DEFAULT '0',
  `gia` decimal(15,3) NOT NULL,
  `tongtien` decimal(15,3) NOT NULL DEFAULT '0.000',
  `trangthai` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(255) NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gia` decimal(15,3) NOT NULL DEFAULT '0.000',
  `mota` text COLLATE utf8_unicode_ci NOT NULL,
  `giamgia` decimal(15,3) NOT NULL,
  `link_anh` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL,
  `quantity` int(11) NOT NULL,
  `keyword` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `catalog_id`, `name`, `gia`, `mota`, `giamgia`, `link_anh`, `date_added`, `quantity`, `keyword`) VALUES
(41, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H2', '25.000', '[Cáº­p cáº£ng SG "6 MÃ“N CHÃˆ NGOáº I LAI" vá»«a hot vá»«a sang cháº£nh]\r\nChÃ¨ du nháº­p tá»« nÆ°á»›c ngÆ°á»i ta, giÃ¡ cÅ©ng theo ngÆ°á»i ta :))). Ngon ghÃª há»“n Ä‘i máº¥y cháº¿, chÃ¨ sang dá»¯ tháº§n záº­y lÃ¢u lÃ¢u má»›i dÃ¡m Äƒn 1 láº§n.', '5.000', 'hop2.jpg', '2016-11-27 09:14:23', 15, 'Hop qua de thuong H2'),
(40, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H1', '35.000', 'Cuá»‘i tuáº§n nÃ y dÃ nh táº·ng mÃ³n quÃ¡ báº¥t ngá» cho ngÆ°á»i áº¥y vá»›i mÃ³n trÃ  sá»¯a háº¡t khá»•ng lá»“, hÃºt bao Ä‘Ã£ nÃ y nhÃ©. Mua háº³n ly to Ä‘á»ƒ cÃ³ Ä‘Æ°á»£c ly nhá»±a cháº¥t lá»« vÃ  2 trÃ¡i tim bÃ© nhá» dá»… thÆ°Æ¡ng gá»­i cho báº¡n áº¥y nhÃ©.', '0.000', 'hop3.jpg', '2016-11-27 09:13:43', 16, 'Hop qua de thuong H1'),
(39, 8, 'Äá»“ng há»“ ná»¯ handmade 1', '160.000', 'ÄÃ¢u coi, trong Ä‘Ã¢y Ad má»›i Äƒn Ä‘Æ°á»£c kem á»‘c quáº¿ Háº¡t Dáº» Ã , táº¡i dá»… tÃ¬m tháº¥y trong máº¥y cá»­a hÃ ng tiá»‡n lá»£i. Máº¥y mÃ³n cÃ²n láº¡i giá» Ä‘ang Ä‘Ã´ng quÃ¡, pháº£i Ä‘á»£i bá»›t hot thÃ¬ má»›i dÃ¡m mon men Ä‘i Äƒn Ä‘Æ°á»£c hihi.', '0.000', 'dongho2.jpg', '2016-11-27 09:12:59', 9, 'dong ho nu handmade 1'),
(38, 3, 'DÃ¢y chuyá»n handmade D1', '90.000', 'Máº¥y nÃ y trá»i láº¡nh bá»‹ thÃ¨m Äƒn láº©u bÃ². Láº©u á»Ÿ Ä‘Ã¢y náº¥u xÆ°Æ¡ng bÃ² nÃªn ráº¥t thÆ¡m, kÃªu cÃ¡i láº©u nhá» 130k cÃ³ náº¡m sá»¥n, gÃ¢n lÆ°á»¡i Ä‘á»§ thá»© mÃºc má»i má»‡t luÃ´n. MÃ³n báº¯p hoa bÃ² nhÃºng á»›t vÃ  gÃ¢n bÃ² chÃ¡y tá»i Äƒn cÅ©ng ngon Ä‘Ã³.', '10.000', 'daychuyen3.jpeg', '2016-11-27 09:12:05', 10, 'Day chuyen handmade D1'),
(37, 5, 'Thiá»‡p handmade T2', '10.000', 'ThÃ¬ ra nhá»¯ng thá»© trÆ°á»›c giá» chÃºng ta nhÃ¬n tháº¥y chá»‰ lÃ  má»™t pháº§n cá»§a nhá»¯ng tÆ°á»£ng Ä‘Ã¡ nÃ y @@\r\nDáº¥u hiá»‡u cá»§a cáº£ má»™t ná»n vÄƒn minh bá»‹ lÃ£ng quÃªn Ä‘ang dáº§n Ä‘Æ°á»£c khÃ¡m phÃ¡ bÃªn dÆ°á»›i Ä‘Ã³ chÄƒng ', '0.000', 'thiep2.jpg', '2016-11-27 09:11:12', 20, 'Thiep handmade T2'),
(36, 7, 'VÃ²ng tay vintage V1', '40.000', 'Má»›i ra máº¯t thÃ´i mÃ  mÃ³n gÃ  rÃ¡n ÄÃ i Loan siÃªu khá»§ng nÃ y Ä‘Ã£ hot quÃ¡ trá»i. GÃ  rÃ¡n giÃ²n Ä‘á»u vÃ  cÃ³ Ä‘á»§ cÃ¡c loáº¡i "topping" hÆ°Æ¡ng vá»‹ tha há»“ cho cÃ¡c báº¡n lá»±a chá»n theo sá»Ÿ thÃ­ch luÃ´n nÃ¨. MÃ¬nh thÃ­ch thÃ¬ click liá»n luÃ´n nÃ¨!', '0.000', 'vongtay2.jpg', '2016-11-27 09:08:57', 20, 'Vong tay vintage V1'),
(33, 3, 'Äá»“ng há»“ quáº£ quÃ½t máº·t hoa vÄƒn', '100.000', 'Äá»“ng há»“ dÃ¢y chuyá»n máº·t hoa vÄƒn', '20.000', 'dongho3.jpg', '2016-11-27 09:05:33', 12, 'dong ho qua quyt mat hoa van'),
(34, 6, 'DÃ¢y chuyá»n máº·t thá» báº¡c', '120.000', 'Cuá»‘i tuáº§n nÃ y dÃ nh táº·ng mÃ³n quÃ¡ báº¥t ngá» cho ngÆ°á»i áº¥y vá»›i mÃ³n trÃ  sá»¯a háº¡t khá»•ng lá»“, hÃºt bao Ä‘Ã£ nÃ y nhÃ©. Mua háº³n ly to Ä‘á»ƒ cÃ³ Ä‘Æ°á»£c ly nhá»±a cháº¥t lá»« vÃ  2 trÃ¡i tim bÃ© nhá» dá»… thÆ°Æ¡ng gá»­i cho báº¡n áº¥y nhÃ¡.', '0.000', 'daychuyen.jpg', '2016-11-27 09:07:09', 9, 'Day chuyen mat tho bac'),
(31, 4, 'Há»™p tiáº¿t kiá»‡m trÃ²n hÃ¬nh thÃº JP55', '40.000', 'Há»™p tiáº¿t kiá»‡m trÃ²n hÃ¬nh thÃº JP55\n\nKÃ­ch thÆ°á»›c : 14 x 7.5 cm\n\nLÆ°u Ã½ : Äiá»n sá»‘ tÆ°Æ¡ng á»©ng máº«u mÃ  báº¡n thÃ­ch vÃ o pháº§n â€œGhi chÃº Ä‘Æ¡n hÃ ngâ€ khi Ä‘áº·t hÃ ng\n\nMÃ£: JP55\nDanh má»¥c: Há»™p quÃ ', '0.000', 'hopqua.jpg', '2016-11-27 08:50:14', 50, 'Hop tiet kiem tron hinh thu JP55'),
(32, 5, 'Thiá»‡p chÃºc má»«ng 1', '60.000', 'Size 30.5 x 30.5cm; Ä‘á»‹nh lÆ°á»£ng 160gsm.\r\n\r\nNhá»¯ng hÃ¬nh áº£nh GiÃ¡ng sinh Ä‘Æ°á»£c trang trÃ­ Ä‘áº¹p máº¯t.\r\n\r\nThiáº¿t káº¿ mÃ u Pastel nháº¹ nhÃ ng vÃ  cá»• Ä‘iá»ƒn, lÃ m scrapbook, thiá»‡p Noel, gÃ³i quÃ ... vÃ´ cÃ¹ng xinh xáº¯n.', '0.000', 'thiep1.JPG', '2016-11-27 09:04:36', 40, 'Thiep chuc mung 1'),
(35, 9, 'MÃ³c khÃ³a handmade 1', '20.000', '[Háº¹n hÃ² vá»›i "TRÃ€ Sá»®A Háº T SIÃŠU KHá»¦NG" bÃ©o bÃ©o - DeliveryNow - Ship táº­n nÆ¡i]', '0.000', 'mockhoa2.jpg', '2016-11-27 09:07:55', 15, 'Moc khoa handmade 1'),
(42, 9, 'MÃ³c khÃ³a handmade M2', '10.000', '[KhÃ´ng Ä‘Ã¢u ráº» hÆ¡n "BÃNH MÃŒ CHáº¢O" 24k/pháº§n]\n1 pháº§n Ä‘áº§y Ä‘á»§ lÃ  24k, nÆ°á»›c sá»‘t Ä‘áº­m Ä‘Ã , cÃ³ pate, thá»‹t bÃ², thá»‹t viÃªn, trá»©ng á»‘p la Äƒn kÃ¨m vá»›i salad dáº§u giáº¥m, Äƒn no láº¯c lÆ°.', '0.000', 'mockhoa1.png', '2016-11-27 09:15:02', 20, 'Moc khoa handmade M2'),
(43, 3, 'DÃ¢y chuyá»n handmade D2', '200.000', '[Canh me vá»‹ trÃ­ Ä‘áº¯c Ä‘á»‹a trong "Lá»„ Há»˜I HOA ANH ÄÃ€O 2017"]\r\nTá»« khÃºc nÃ y mÃ  nhÃ¬n xuá»‘ng dÃ n hoa mai anh Ä‘Ã o Ä‘áº¹p rung rinh luÃ´n á»›, chá»¥p hÃ¬nh cÅ©ng dá»… ná»¯a, bon chen dÆ°á»›i mÃ­ chá»— kia chi cho má»£t.', '40.000', 'daychuyen1.jpg', '2016-11-27 09:16:07', 25, 'Day chuyen handmade D2'),
(44, 5, 'Thiá»‡p handmade T3', '12.000', '[Canh me vá»‹ trÃ­ Ä‘áº¯c Ä‘á»‹a trong "Lá»„ Há»˜I HOA ANH ÄÃ€O 2017"]\r\nTá»« khÃºc nÃ y mÃ  nhÃ¬n xuá»‘ng dÃ n hoa mai anh Ä‘Ã o Ä‘áº¹p rung rinh luÃ´n á»›, chá»¥p hÃ¬nh cÅ©ng dá»… ná»¯a, bon chen dÆ°á»›i mÃ­ chá»— kia chi cho má»£t.', '0.000', 'thiep3.jpg', '2016-11-27 09:16:33', 15, 'Thiep handmade T3'),
(45, 7, 'VÃ²ng tay vintage V2', '65.000', '[Canh me vá»‹ trÃ­ Ä‘áº¯c Ä‘á»‹a trong "Lá»„ Há»˜I HOA ANH ÄÃ€O 2017"]\r\nTá»« khÃºc nÃ y mÃ  nhÃ¬n xuá»‘ng dÃ n hoa mai anh Ä‘Ã o Ä‘áº¹p rung rinh luÃ´n á»›, chá»¥p hÃ¬nh cÅ©ng dá»… ná»¯a, bon chen dÆ°á»›i mÃ­ chá»— kia chi cho má»£t.', '0.000', 'vongtay1.jpg', '2016-11-27 09:17:01', 22, 'Vong tay vintage V2'),
(46, 9, 'MÃ³c khÃ³a handmade M3', '16.000', '[MUA HÃ€NG Má»¸ GIÃ Ráºº Cáº£ NÄƒm Nhá» Thuá»™c Lá»‹ch Sale NhÆ° ChÃ¡o]\r\nAi lÃ  fan cuá»“ng hÃ ng xÃ¡ch tay Má»¹ thÃ¬ note láº¡i ngay máº¥y dá»‹p lá»… sale bá»± nÃ y nha. Báº£o Ä‘áº£m xÃ i hÃ ng "há»‹n" mÃ£n Ä‘á»i mÃ  khÃ´ng lo vá» giÃ¡.', '0.000', 'mockhoa4.jpg', '2016-11-27 09:17:39', 12, 'Moc khoa handmade M3'),
(47, 8, 'Äá»“ng há»“ ná»¯ handmade 2', '180.000', '[MUA HÃ€NG Má»¸ GIÃ Ráºº Cáº£ NÄƒm Nhá» Thuá»™c Lá»‹ch Sale NhÆ° ChÃ¡o]\r\nAi lÃ  fan cuá»“ng hÃ ng xÃ¡ch tay Má»¹ thÃ¬ note láº¡i ngay máº¥y dá»‹p lá»… sale bá»± nÃ y nha. Báº£o Ä‘áº£m xÃ i hÃ ng "há»‹n" mÃ£n Ä‘á»i mÃ  khÃ´ng lo vá» giÃ¡.', '0.000', 'dongho5.jpg', '2016-11-27 09:18:11', 12, 'dong ho nu handmade 2'),
(48, 3, 'MÃ³c khÃ³a handmade M4', '25.000', '[MUA HÃ€NG Má»¸ GIÃ Ráºº Cáº£ NÄƒm Nhá» Thuá»™c Lá»‹ch Sale NhÆ° ChÃ¡o]\r\nAi lÃ  fan cuá»“ng hÃ ng xÃ¡ch tay Má»¹ thÃ¬ note láº¡i ngay máº¥y dá»‹p lá»… sale bá»± nÃ y nha. Báº£o Ä‘áº£m xÃ i hÃ ng "há»‹n" mÃ£n Ä‘á»i mÃ  khÃ´ng lo vá» giÃ¡.', '5.000', 'mockhoa3.jpg', '2016-11-27 09:18:49', 10, 'Moc khoa handmade M4'),
(49, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H3', '70.000', '["6 CHUá»–I COFFEE SHOP" Ä‘a phong cÃ¡ch Ä‘Æ°á»£c yÃªu thÃ­ch nháº¥t SG]\r\nStyle cá»• Ä‘iá»ƒn, bá»¥i báº·m, cÃ¡ tÃ­nh hay lá»™ng láº«y nhÆ° chÃ¢u Ã‚u Ä‘á»u cÃ³ á»Ÿ 6 chuá»—i coffee nÃ y nhÃ©. KhÃ´ng gian chuáº©n khÃ´ng cáº§n chá»‰nh, phe sá»‘ng áº£o note vá» nÃ¨.', '0.000', 'hop4.jpg', '2016-11-27 09:19:17', 25, 'Hop qua de thuong H3'),
(50, 7, 'VÃ²ng tay vintage V3', '45.000', '["6 CHUá»–I COFFEE SHOP" Ä‘a phong cÃ¡ch Ä‘Æ°á»£c yÃªu thÃ­ch nháº¥t SG]\r\nStyle cá»• Ä‘iá»ƒn, bá»¥i báº·m, cÃ¡ tÃ­nh hay lá»™ng láº«y nhÆ° chÃ¢u Ã‚u Ä‘á»u cÃ³ á»Ÿ 6 chuá»—i coffee nÃ y nhÃ©. KhÃ´ng gian chuáº©n khÃ´ng cáº§n chá»‰nh, phe sá»‘ng áº£o note vá» nÃ¨.', '0.000', 'vongtay3.jpg', '2016-11-27 09:19:44', 20, 'Vong tay vintage V3'),
(51, 6, 'DÃ¢y chuyá»n handmade D3', '250.000', '["6 CHUá»–I COFFEE SHOP" Ä‘a phong cÃ¡ch Ä‘Æ°á»£c yÃªu thÃ­ch nháº¥t SG]\r\nStyle cá»• Ä‘iá»ƒn, bá»¥i báº·m, cÃ¡ tÃ­nh hay lá»™ng láº«y nhÆ° chÃ¢u Ã‚u Ä‘á»u cÃ³ á»Ÿ 6 chuá»—i coffee nÃ y nhÃ©. KhÃ´ng gian chuáº©n khÃ´ng cáº§n chá»‰nh, phe sá»‘ng áº£o note vá» nÃ¨.', '0.000', 'daychuyen1.jpg', '2016-11-27 09:20:16', 15, 'Day chuyen handmade D3'),
(52, 3, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H4', '35.000', '[Láº¡nh toÃ¡t ngÆ°á»i á»Ÿ "TU VIá»†N Cá»”" xÃ¢y tá»« 1942 Ã­t ai dÃ¡m Ä‘áº¿n]\r\nBan ngÃ y cÃ²n Ä‘á»¡, táº§m cháº¡ng váº¡ng thÃ¬ nhiá»‡t Ä‘á»™ báº¯t Ä‘áº§u giáº£m xuá»‘ng mÃ  Ä‘áº­m cháº¥t "phim ma" luÃ´n. AI Ä‘ang cáº§n tÃ¬m nÆ¡i chá»¥p nhá»¯ng bá»™ áº£nh ma má»‹ thÃ¬ Ä‘áº¿n Ä‘Ã¢y nÃ¨.', '5.000', 'hop4.jpg', '2016-11-27 09:22:32', 15, 'Hop qua de thuong H4'),
(53, 7, 'VÃ²ng tay vintage V4', '65.000', '[Láº¡nh toÃ¡t ngÆ°á»i á»Ÿ "TU VIá»†N Cá»”" xÃ¢y tá»« 1942 Ã­t ai dÃ¡m Ä‘áº¿n]\r\nBan ngÃ y cÃ²n Ä‘á»¡, táº§m cháº¡ng váº¡ng thÃ¬ nhiá»‡t Ä‘á»™ báº¯t Ä‘áº§u giáº£m xuá»‘ng mÃ  Ä‘áº­m cháº¥t "phim ma" luÃ´n. AI Ä‘ang cáº§n tÃ¬m nÆ¡i chá»¥p nhá»¯ng bá»™ áº£nh ma má»‹ thÃ¬ Ä‘áº¿n Ä‘Ã¢y nÃ¨.', '0.000', 'vongtay5.jpg', '2016-11-27 09:23:43', 20, 'Vong tay vintage V4'),
(54, 7, 'VÃ²ng tay vintage V5', '80.000', '["ÄANG TRÃŠN ÄÆ¯á»œNG CMT8" thÃ¬ Äƒn gÃ¬ ngon Ä‘Ã¢y?]\r\nÄ‚n á»‘c nha, beefsteak, láº©u bÃ², hay láº©u cua, bÃ¡nh su Sin...Ä‘Æ°á»ng nÃ y Ä‘á»“ Äƒn Ãª há», nhÆ°ng pháº£i lá»±a máº¥y mÃ³n ngon chá»©, pháº£i khÃ´ng? Tham kháº£o nha bÃ  con.', '0.000', 'vongtay1.jpg', '2016-11-27 09:24:15', 25, 'Vong tay vintage V5'),
(55, 5, 'Thiá»‡p handmade T4', '20.000', '["ÄANG TRÃŠN ÄÆ¯á»œNG CMT8" thÃ¬ Äƒn gÃ¬ ngon Ä‘Ã¢y?]\r\nÄ‚n á»‘c nha, beefsteak, láº©u bÃ², hay láº©u cua, bÃ¡nh su Sin...Ä‘Æ°á»ng nÃ y Ä‘á»“ Äƒn Ãª há», nhÆ°ng pháº£i lá»±a máº¥y mÃ³n ngon chá»©, pháº£i khÃ´ng? Tham kháº£o nha bÃ  con.', '0.000', 'thiep1.JPG', '2016-11-27 09:24:37', 25, 'Thiep handmade T4'),
(56, 6, 'DÃ¢y chuyá»n handmade D3', '200.000', '["ÄANG TRÃŠN ÄÆ¯á»œNG CMT8" thÃ¬ Äƒn gÃ¬ ngon Ä‘Ã¢y?]\r\nÄ‚n á»‘c nha, beefsteak, láº©u bÃ², hay láº©u cua, bÃ¡nh su Sin...Ä‘Æ°á»ng nÃ y Ä‘á»“ Äƒn Ãª há», nhÆ°ng pháº£i lá»±a máº¥y mÃ³n ngon chá»©, pháº£i khÃ´ng? Tham kháº£o nha bÃ  con.', '0.000', 'daychuyen4.jpg', '2016-11-27 09:24:59', 16, 'Day chuyen handmade D3'),
(57, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H5', '60.000', '["ÄANG TRÃŠN ÄÆ¯á»œNG CMT8" thÃ¬ Äƒn gÃ¬ ngon Ä‘Ã¢y?]\r\nÄ‚n á»‘c nha, beefsteak, láº©u bÃ², hay láº©u cua, bÃ¡nh su Sin...Ä‘Æ°á»ng nÃ y Ä‘á»“ Äƒn Ãª há», nhÆ°ng pháº£i lá»±a máº¥y mÃ³n ngon chá»©, pháº£i khÃ´ng? Tham kháº£o nha bÃ  con.', '0.000', 'hop3.jpg', '2016-11-27 09:25:30', 30, 'Hop qua de thuong H5'),
(58, 9, 'MÃ³c khÃ³a handmade M5', '18.000', '[TÃ¬m báº±ng Ä‘Æ°á»£c xe "SÃšP CUA BÃNH MÃŒ GIÃ’N" chá»‰ 12k/ly ráº¥t ngon]\r\nVá»‹ sÃºp Ä‘áº­m Ä‘Ã , bÃªn trÃªn cÃ³ thÃªm vá»¥n bÃ¡nh mÃ¬ giÃ²n Äƒn Ä‘Ã£ dá»… sá»£, giÃ¡ 12k/ly nhÃ©. Xe bÃ¡n Ä‘Ã´ng khÃ¡ch nÃªn nhanh háº¿t láº¯m, má»i ngÆ°á»i tranh thá»§ Ä‘i sá»›m xÃ­ nha.', '0.000', 'mockhoa4.jpg', '2016-11-27 09:26:02', 18, 'Moc khoa handmade M5'),
(59, 8, 'Äá»“ng há»“ handmade 1', '135.000', '[TÃ¬m báº±ng Ä‘Æ°á»£c xe "SÃšP CUA BÃNH MÃŒ GIÃ’N" chá»‰ 12k/ly ráº¥t ngon]\r\nVá»‹ sÃºp Ä‘áº­m Ä‘Ã , bÃªn trÃªn cÃ³ thÃªm vá»¥n bÃ¡nh mÃ¬ giÃ²n Äƒn Ä‘Ã£ dá»… sá»£, giÃ¡ 12k/ly nhÃ©. Xe bÃ¡n Ä‘Ã´ng khÃ¡ch nÃªn nhanh háº¿t láº¯m, má»i ngÆ°á»i tranh thá»§ Ä‘i sá»›m xÃ­ nha.', '0.000', 'dongho1.jpg', '2016-11-27 09:26:33', 30, 'dong ho handmade 1'),
(60, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H6', '45.000', '[TÃ¬m báº±ng Ä‘Æ°á»£c xe "SÃšP CUA BÃNH MÃŒ GIÃ’N" chá»‰ 12k/ly ráº¥t ngon]\r\nVá»‹ sÃºp Ä‘áº­m Ä‘Ã , bÃªn trÃªn cÃ³ thÃªm vá»¥n bÃ¡nh mÃ¬ giÃ²n Äƒn Ä‘Ã£ dá»… sá»£, giÃ¡ 12k/ly nhÃ©. Xe bÃ¡n Ä‘Ã´ng khÃ¡ch nÃªn nhanh háº¿t láº¯m, má»i ngÆ°á»i tranh thá»§ Ä‘i sá»›m xÃ­ nha.', '0.000', 'hop2.jpg', '2016-11-27 09:26:56', 25, 'Hop qua de thuong H6'),
(61, 7, 'VÃ²ng tay vintage V6', '120.000', '[Mua Má»¹ Pháº©m ÄÆ°á»£c SOI DA MIá»„N PHÃ TRá»ŒN Äá»œI]\r\nTrá»i Æ¡i, ai mÃ  lá»¡ sa chÃ¢n vÃ´ chá»‘n nÃ y lÃ  chá»‰ cÃ³ gom hÃ ng Ä‘iÃªn Ä‘áº£o thÃ´i nha. ÄÃ£ váº­y cÃ²n Ä‘Æ°á»£c soi da miá»…n phÃ­ trá»n kiáº¿p ná»¯a. QuÃ¡ Ä‘Ã£!', '0.000', 'vongtay2.jpg', '2016-11-27 09:27:22', 18, 'Vong tay vintage V6'),
(62, 3, 'DÃ¢y chuyá»n handmade D4', '300.000', '[Mua Má»¹ Pháº©m ÄÆ°á»£c SOI DA MIá»„N PHÃ TRá»ŒN Äá»œI]\r\nTrá»i Æ¡i, ai mÃ  lá»¡ sa chÃ¢n vÃ´ chá»‘n nÃ y lÃ  chá»‰ cÃ³ gom hÃ ng Ä‘iÃªn Ä‘áº£o thÃ´i nha. ÄÃ£ váº­y cÃ²n Ä‘Æ°á»£c soi da miá»…n phÃ­ trá»n kiáº¿p ná»¯a. QuÃ¡ Ä‘Ã£!', '40.000', 'daychuyen2.jpg', '2016-11-27 09:27:48', 16, 'Day chuyen handmade D4'),
(63, 8, 'Äá»“ng há»“ handmade 2', '165.000', '[Mua Má»¹ Pháº©m ÄÆ°á»£c SOI DA MIá»„N PHÃ TRá»ŒN Äá»œI]\r\nTrá»i Æ¡i, ai mÃ  lá»¡ sa chÃ¢n vÃ´ chá»‘n nÃ y lÃ  chá»‰ cÃ³ gom hÃ ng Ä‘iÃªn Ä‘áº£o thÃ´i nha. ÄÃ£ váº­y cÃ²n Ä‘Æ°á»£c soi da miá»…n phÃ­ trá»n kiáº¿p ná»¯a. QuÃ¡ Ä‘Ã£!', '0.000', 'dongho4.jpg', '2016-11-27 09:28:08', 15, 'dong ho handmade 2'),
(64, 5, 'Thiá»‡p handmade T5', '32.000', '[Mua Má»¹ Pháº©m ÄÆ°á»£c SOI DA MIá»„N PHÃ TRá»ŒN Äá»œI]\r\nTrá»i Æ¡i, ai mÃ  lá»¡ sa chÃ¢n vÃ´ chá»‘n nÃ y lÃ  chá»‰ cÃ³ gom hÃ ng Ä‘iÃªn Ä‘áº£o thÃ´i nha. ÄÃ£ váº­y cÃ²n Ä‘Æ°á»£c soi da miá»…n phÃ­ trá»n kiáº¿p ná»¯a. QuÃ¡ Ä‘Ã£!', '0.000', 'thiep2.jpg', '2016-11-27 09:28:30', 15, 'Thiep handmade T5'),
(65, 3, 'DÃ¢y chuyá»n handmade D4', '280.000', 'MÃ³n ngon bÃ¡ chÃ¡y, báº¯p bÃ² cháº¯c ná»‹ch thÆ¡m phÆ°ng phá»©c Ä‘Æ°á»£c sáº¯t lÃ¡t, phá»§ vá»«a máº·t bÃ¡nh trÃ¡ng cuá»™n vá»›i cÃ¡c vá»‹ rau rá»«ng, Ä‘iá»ƒm vÃ i tÃ©p gÃ¢n cáº¯n vÃ o sá»«ng sá»±c ráº¥t thÃ­ch miá»‡ng. NhÃ  hÃ ng Ä‘ang Æ°u Ä‘Ã£i mua 1 pháº§n báº¯p bÃ² chá»‰ 148k táº·ng ngay 1 pháº§n gá»i cuá»‘n Ãº nu hay cuá»‘n diáº¿p, bÃ² bÃ­a."', '50.000', 'daychuyen3.jpeg', '2016-11-27 09:29:27', 15, 'Day chuyen handmade D4'),
(66, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H7', '45.000', 'MÃ³n ngon bÃ¡ chÃ¡y, báº¯p bÃ² cháº¯c ná»‹ch thÆ¡m phÆ°ng phá»©c Ä‘Æ°á»£c sáº¯t lÃ¡t, phá»§ vá»«a máº·t bÃ¡nh trÃ¡ng cuá»™n vá»›i cÃ¡c vá»‹ rau rá»«ng, Ä‘iá»ƒm vÃ i tÃ©p gÃ¢n cáº¯n vÃ o sá»«ng sá»±c ráº¥t thÃ­ch miá»‡ng. NhÃ  hÃ ng Ä‘ang Æ°u Ä‘Ã£i mua 1 pháº§n báº¯p bÃ² chá»‰ 148k táº·ng ngay 1 pháº§n gá»i cuá»‘n Ãº nu hay cuá»‘n diáº¿p, bÃ² bÃ­a."', '0.000', 'hop4.jpg', '2016-11-27 09:29:49', 24, 'Hop qua de thuong H7'),
(67, 9, 'MÃ³c khÃ³a handmade M6', '12.000', 'MÃ³n ngon bÃ¡ chÃ¡y, báº¯p bÃ² cháº¯c ná»‹ch thÆ¡m phÆ°ng phá»©c Ä‘Æ°á»£c sáº¯t lÃ¡t, phá»§ vá»«a máº·t bÃ¡nh trÃ¡ng cuá»™n vá»›i cÃ¡c vá»‹ rau rá»«ng, Ä‘iá»ƒm vÃ i tÃ©p gÃ¢n cáº¯n vÃ o sá»«ng sá»±c ráº¥t thÃ­ch miá»‡ng. NhÃ  hÃ ng Ä‘ang Æ°u Ä‘Ã£i mua 1 pháº§n báº¯p bÃ² chá»‰ 148k táº·ng ngay 1 pháº§n gá»i cuá»‘n Ãº nu hay cuá»‘n diáº¿p, bÃ² bÃ­a."', '0.000', 'mockhoa4.jpg', '2016-11-27 09:30:12', 20, 'Moc khoa handmade M6'),
(68, 5, 'Thiá»‡p handmade T6', '25.000', 'MÃ³n ngon bÃ¡ chÃ¡y, báº¯p bÃ² cháº¯c ná»‹ch thÆ¡m phÆ°ng phá»©c Ä‘Æ°á»£c sáº¯t lÃ¡t, phá»§ vá»«a máº·t bÃ¡nh trÃ¡ng cuá»™n vá»›i cÃ¡c vá»‹ rau rá»«ng, Ä‘iá»ƒm vÃ i tÃ©p gÃ¢n cáº¯n vÃ o sá»«ng sá»±c ráº¥t thÃ­ch miá»‡ng. NhÃ  hÃ ng Ä‘ang Æ°u Ä‘Ã£i mua 1 pháº§n báº¯p bÃ² chá»‰ 148k táº·ng ngay 1 pháº§n gá»i cuá»‘n Ãº nu hay cuá»‘n diáº¿p, bÃ² bÃ­a."', '0.000', 'thiep1.JPG', '2016-11-27 09:30:36', 26, 'Thiep handmade T6'),
(69, 6, 'DÃ¢y chuyá»n handmade D5', '250.000', 'MÃ³n ngon bÃ¡ chÃ¡y, báº¯p bÃ² cháº¯c ná»‹ch thÆ¡m phÆ°ng phá»©c Ä‘Æ°á»£c sáº¯t lÃ¡t, phá»§ vá»«a máº·t bÃ¡nh trÃ¡ng cuá»™n vá»›i cÃ¡c vá»‹ rau rá»«ng, Ä‘iá»ƒm vÃ i tÃ©p gÃ¢n cáº¯n vÃ o sá»«ng sá»±c ráº¥t thÃ­ch miá»‡ng. NhÃ  hÃ ng Ä‘ang Æ°u Ä‘Ã£i mua 1 pháº§n báº¯p bÃ² chá»‰ 148k táº·ng ngay 1 pháº§n gá»i cuá»‘n Ãº nu hay cuá»‘n diáº¿p, bÃ² bÃ­a."', '0.000', 'daychuyen1.jpg', '2016-11-27 09:30:54', 15, 'Day chuyen handmade D5'),
(70, 7, 'VÃ²ng tay vintage V7', '120.000', '[Dáº¯t gáº¥u má»›i yÃªu Ä‘i "Háº¸N HÃ’ 100K" cháº¥t lá»« kháº¯p SG]\r\n100k cÅ©ng lÃ m nÃªn chuyá»‡n Ä‘Ã³ chá»© giá»¡n. Ä‚n dimsum Ä‘Æ°á»ng phá»‘, xong dáº¯t qua uá»‘ng macchiato, xong, no nÃª :v. Máº¥y cáº·p Ä‘Ã´i má»›i yÃªu tham kháº£o thá»­ coi nÃ .', '0.000', 'vongtay4.jpg', '2016-11-27 09:31:19', 30, 'Vong tay vintage V7'),
(71, 6, 'DÃ¢y chuyá»n handmade D5', '200.000', '[Dáº¯t gáº¥u má»›i yÃªu Ä‘i "Háº¸N HÃ’ 100K" cháº¥t lá»« kháº¯p SG]\r\n100k cÅ©ng lÃ m nÃªn chuyá»‡n Ä‘Ã³ chá»© giá»¡n. Ä‚n dimsum Ä‘Æ°á»ng phá»‘, xong dáº¯t qua uá»‘ng macchiato, xong, no nÃª :v. Máº¥y cáº·p Ä‘Ã´i má»›i yÃªu tham kháº£o thá»­ coi nÃ .', '0.000', 'daychuyen4.jpg', '2016-11-27 09:31:40', 20, 'Day chuyen handmade D5'),
(72, 8, 'Äá»“ng há»“ ná»¯ handmade 3', '110.000', '[Dáº¯t gáº¥u má»›i yÃªu Ä‘i "Háº¸N HÃ’ 100K" cháº¥t lá»« kháº¯p SG]\r\n100k cÅ©ng lÃ m nÃªn chuyá»‡n Ä‘Ã³ chá»© giá»¡n. Ä‚n dimsum Ä‘Æ°á»ng phá»‘, xong dáº¯t qua uá»‘ng macchiato, xong, no nÃª :v. Máº¥y cáº·p Ä‘Ã´i má»›i yÃªu tham kháº£o thá»­ coi nÃ .', '0.000', 'dongho2.jpg', '2016-11-27 09:32:00', 20, 'dong ho nu handmade 3'),
(73, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H8', '78.000', '["10 MÃ“N Vá»ªA ÄI Vá»ªA Ä‚N" tÃ¡n tá»‰nh thÃ nh cÃ´ng giá»›i tráº» SG]\r\nNhá»¯ng mÃ³n nÃ y cáº§m gá»n lá»n trÃªn tay, vá»«a Ä‘i dáº¡o vá»«a mÄƒm mÄƒm cÃ ng thÃ­ch nha. Tá»« há»“i má»›i xuáº¥t hiá»‡n tá»›i giá» cÃ¡c em nÃ³ váº«n Ä‘Ã´ng khÃ¡ch Ä‘á»u Ä‘á»u, khÃ´ng cÃ³ dáº¥u hiá»‡u háº¡ nhiá»‡t luÃ´n :p.', '0.000', 'hop3.jpg', '2016-11-27 09:32:41', 24, 'Hop qua de thuong H8'),
(74, 6, 'DÃ¢y chuyá»n handmade D6', '195.000', '["10 MÃ“N Vá»ªA ÄI Vá»ªA Ä‚N" tÃ¡n tá»‰nh thÃ nh cÃ´ng giá»›i tráº» SG]\r\nNhá»¯ng mÃ³n nÃ y cáº§m gá»n lá»n trÃªn tay, vá»«a Ä‘i dáº¡o vá»«a mÄƒm mÄƒm cÃ ng thÃ­ch nha. Tá»« há»“i má»›i xuáº¥t hiá»‡n tá»›i giá» cÃ¡c em nÃ³ váº«n Ä‘Ã´ng khÃ¡ch Ä‘á»u Ä‘á»u, khÃ´ng cÃ³ dáº¥u hiá»‡u háº¡ nhiá»‡t luÃ´n :p.', '0.000', 'daychuyen3.jpeg', '2016-11-27 09:33:02', 25, 'Day chuyen handmade D6'),
(75, 9, 'MÃ³c khÃ³a handmade M7', '35.000', '["10 MÃ“N Vá»ªA ÄI Vá»ªA Ä‚N" tÃ¡n tá»‰nh thÃ nh cÃ´ng giá»›i tráº» SG]\r\nNhá»¯ng mÃ³n nÃ y cáº§m gá»n lá»n trÃªn tay, vá»«a Ä‘i dáº¡o vá»«a mÄƒm mÄƒm cÃ ng thÃ­ch nha. Tá»« há»“i má»›i xuáº¥t hiá»‡n tá»›i giá» cÃ¡c em nÃ³ váº«n Ä‘Ã´ng khÃ¡ch Ä‘á»u Ä‘á»u, khÃ´ng cÃ³ dáº¥u hiá»‡u háº¡ nhiá»‡t luÃ´n :p.', '0.000', 'mockhoa1.png', '2016-11-27 09:33:30', 20, 'Moc khoa handmade M7'),
(76, 5, 'Thiá»‡p handmade T7', '45.000', '["10 MÃ“N Vá»ªA ÄI Vá»ªA Ä‚N" tÃ¡n tá»‰nh thÃ nh cÃ´ng giá»›i tráº» SG]\r\nNhá»¯ng mÃ³n nÃ y cáº§m gá»n lá»n trÃªn tay, vá»«a Ä‘i dáº¡o vá»«a mÄƒm mÄƒm cÃ ng thÃ­ch nha. Tá»« há»“i má»›i xuáº¥t hiá»‡n tá»›i giá» cÃ¡c em nÃ³ váº«n Ä‘Ã´ng khÃ¡ch Ä‘á»u Ä‘á»u, khÃ´ng cÃ³ dáº¥u hiá»‡u háº¡ nhiá»‡t luÃ´n :p.', '0.000', 'thiep3.jpg', '2016-11-27 09:33:56', 15, 'Thiep handmade T7'),
(77, 8, 'Äá»“ng há»“ handmade 3', '140.000', '["10 MÃ“N Vá»ªA ÄI Vá»ªA Ä‚N" tÃ¡n tá»‰nh thÃ nh cÃ´ng giá»›i tráº» SG]\r\nNhá»¯ng mÃ³n nÃ y cáº§m gá»n lá»n trÃªn tay, vá»«a Ä‘i dáº¡o vá»«a mÄƒm mÄƒm cÃ ng thÃ­ch nha. Tá»« há»“i má»›i xuáº¥t hiá»‡n tá»›i giá» cÃ¡c em nÃ³ váº«n Ä‘Ã´ng khÃ¡ch Ä‘á»u Ä‘á»u, khÃ´ng cÃ³ dáº¥u hiá»‡u háº¡ nhiá»‡t luÃ´n :p.', '0.000', 'dongho4.jpg', '2016-11-27 09:34:55', 20, 'dong ho handmade 3'),
(78, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H9', '55.000', '["10 MÃ“N Vá»ªA ÄI Vá»ªA Ä‚N" tÃ¡n tá»‰nh thÃ nh cÃ´ng giá»›i tráº» SG]\r\nNhá»¯ng mÃ³n nÃ y cáº§m gá»n lá»n trÃªn tay, vá»«a Ä‘i dáº¡o vá»«a mÄƒm mÄƒm cÃ ng thÃ­ch nha. Tá»« há»“i má»›i xuáº¥t hiá»‡n tá»›i giá» cÃ¡c em nÃ³ váº«n Ä‘Ã´ng khÃ¡ch Ä‘á»u Ä‘á»u, khÃ´ng cÃ³ dáº¥u hiá»‡u háº¡ nhiá»‡t luÃ´n :p.', '0.000', 'hop4.jpg', '2016-11-27 09:35:15', 15, 'Hop qua de thuong H9'),
(79, 9, 'MÃ³c khÃ³a handmade M8', '35.000', '["10 MÃ“N Vá»ªA ÄI Vá»ªA Ä‚N" tÃ¡n tá»‰nh thÃ nh cÃ´ng giá»›i tráº» SG]\r\nNhá»¯ng mÃ³n nÃ y cáº§m gá»n lá»n trÃªn tay, vá»«a Ä‘i dáº¡o vá»«a mÄƒm mÄƒm cÃ ng thÃ­ch nha. Tá»« há»“i má»›i xuáº¥t hiá»‡n tá»›i giá» cÃ¡c em nÃ³ váº«n Ä‘Ã´ng khÃ¡ch Ä‘á»u Ä‘á»u, khÃ´ng cÃ³ dáº¥u hiá»‡u háº¡ nhiá»‡t luÃ´n :p.', '0.000', 'mockhoa2.jpg', '2016-11-27 09:35:34', 10, 'Moc khoa handmade M8'),
(80, 6, 'DÃ¢y chuyá»n handmade D7', '165.000', 'QuÃ¡n gÃ¬ Ä‘Ã¢u kute tá»« cÃ¡i tÃªn cho tá»›i cÃ¡ch decor quÃ¡n, sá»‘ng áº£o bá»±a khá»i nÃ³i. MÃ³n nÃ o trong menu cÃ³ whipping cream Ä‘á»u ngon háº¿t nha, nhá»› canh khung giá» vÃ ng 14-18h má»›i Ä‘i, Ä‘Æ°á»£c giáº£m 25% láº­n Ä‘Ã³.', '0.000', 'daychuyen.jpg', '2016-11-27 09:36:01', 25, 'Day chuyen handmade D7'),
(81, 5, 'Thiá»‡p handmade T8', '46.000', 'QuÃ¡n gÃ¬ Ä‘Ã¢u kute tá»« cÃ¡i tÃªn cho tá»›i cÃ¡ch decor quÃ¡n, sá»‘ng áº£o bá»±a khá»i nÃ³i. MÃ³n nÃ o trong menu cÃ³ whipping cream Ä‘á»u ngon háº¿t nha, nhá»› canh khung giá» vÃ ng 14-18h má»›i Ä‘i, Ä‘Æ°á»£c giáº£m 25% láº­n Ä‘Ã³.', '0.000', 'thiep1.JPG', '2016-11-27 09:36:23', 30, 'Thiep handmade T8'),
(82, 7, 'VÃ²ng tay vintage V8', '120.000', 'QuÃ¡n gÃ¬ Ä‘Ã¢u kute tá»« cÃ¡i tÃªn cho tá»›i cÃ¡ch decor quÃ¡n, sá»‘ng áº£o bá»±a khá»i nÃ³i. MÃ³n nÃ o trong menu cÃ³ whipping cream Ä‘á»u ngon háº¿t nha, nhá»› canh khung giá» vÃ ng 14-18h má»›i Ä‘i, Ä‘Æ°á»£c giáº£m 25% láº­n Ä‘Ã³.', '0.000', 'vongtay2.jpg', '2016-11-27 09:36:46', 20, 'Vong tay vintage V8'),
(83, 3, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H10', '80.000', 'QuÃ¡n gÃ¬ Ä‘Ã¢u kute tá»« cÃ¡i tÃªn cho tá»›i cÃ¡ch decor quÃ¡n, sá»‘ng áº£o bá»±a khá»i nÃ³i. MÃ³n nÃ o trong menu cÃ³ whipping cream Ä‘á»u ngon háº¿t nha, nhá»› canh khung giá» vÃ ng 14-18h má»›i Ä‘i, Ä‘Æ°á»£c giáº£m 25% láº­n Ä‘Ã³.', '10.000', 'hop3.jpg', '2016-11-27 09:37:14', 10, 'Hop qua de thuong H10'),
(84, 7, 'VÃ²ng tay vintage V9', '86.000', 'Máº¥y nÃ y trá»i láº¡nh bá»‹ thÃ¨m Äƒn láº©u bÃ². Láº©u á»Ÿ Ä‘Ã¢y náº¥u xÆ°Æ¡ng bÃ² nÃªn ráº¥t thÆ¡m, kÃªu cÃ¡i láº©u nhá» 130k cÃ³ náº¡m sá»¥n, gÃ¢n lÆ°á»¡i Ä‘á»§ thá»© mÃºc má»i má»‡t luÃ´n. MÃ³n báº¯p hoa bÃ² nhÃºng á»›t vÃ  gÃ¢n bÃ² chÃ¡y tá»i Äƒn cÅ©ng ngon Ä‘Ã³.', '0.000', 'vongtay1.jpg', '2016-11-27 09:37:57', 25, 'Vong tay vintage V9'),
(85, 8, 'Äá»“ng há»“ handmade 4', '250.000', 'Máº¥y nÃ y trá»i láº¡nh bá»‹ thÃ¨m Äƒn láº©u bÃ². Láº©u á»Ÿ Ä‘Ã¢y náº¥u xÆ°Æ¡ng bÃ² nÃªn ráº¥t thÆ¡m, kÃªu cÃ¡i láº©u nhá» 130k cÃ³ náº¡m sá»¥n, gÃ¢n lÆ°á»¡i Ä‘á»§ thá»© mÃºc má»i má»‡t luÃ´n. MÃ³n báº¯p hoa bÃ² nhÃºng á»›t vÃ  gÃ¢n bÃ² chÃ¡y tá»i Äƒn cÅ©ng ngon Ä‘Ã³.', '0.000', 'dongho5.jpg', '2016-11-27 09:38:21', 15, 'dong ho handmade 4'),
(86, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H11', '180.000', 'Máº¥y nÃ y trá»i láº¡nh bá»‹ thÃ¨m Äƒn láº©u bÃ². Láº©u á»Ÿ Ä‘Ã¢y náº¥u xÆ°Æ¡ng bÃ² nÃªn ráº¥t thÆ¡m, kÃªu cÃ¡i láº©u nhá» 130k cÃ³ náº¡m sá»¥n, gÃ¢n lÆ°á»¡i Ä‘á»§ thá»© mÃºc má»i má»‡t luÃ´n. MÃ³n báº¯p hoa bÃ² nhÃºng á»›t vÃ  gÃ¢n bÃ² chÃ¡y tá»i Äƒn cÅ©ng ngon Ä‘Ã³.', '0.000', 'hop4.jpg', '2016-11-27 09:38:46', 20, 'Hop qua de thuong H11'),
(87, 6, 'DÃ¢y chuyá»n handmade D8', '120.000', 'Máº¥y nÃ y trá»i láº¡nh bá»‹ thÃ¨m Äƒn láº©u bÃ². Láº©u á»Ÿ Ä‘Ã¢y náº¥u xÆ°Æ¡ng bÃ² nÃªn ráº¥t thÆ¡m, kÃªu cÃ¡i láº©u nhá» 130k cÃ³ náº¡m sá»¥n, gÃ¢n lÆ°á»¡i Ä‘á»§ thá»© mÃºc má»i má»‡t luÃ´n. MÃ³n báº¯p hoa bÃ² nhÃºng á»›t vÃ  gÃ¢n bÃ² chÃ¡y tá»i Äƒn cÅ©ng ngon Ä‘Ã³.', '0.000', 'daychuyen2.jpg', '2016-11-27 09:39:11', 18, 'Day chuyen handmade D8'),
(88, 9, 'MÃ³c khÃ³a handmade M9', '55.000', 'Máº¥y nÃ y trá»i láº¡nh bá»‹ thÃ¨m Äƒn láº©u bÃ². Láº©u á»Ÿ Ä‘Ã¢y náº¥u xÆ°Æ¡ng bÃ² nÃªn ráº¥t thÆ¡m, kÃªu cÃ¡i láº©u nhá» 130k cÃ³ náº¡m sá»¥n, gÃ¢n lÆ°á»¡i Ä‘á»§ thá»© mÃºc má»i má»‡t luÃ´n. MÃ³n báº¯p hoa bÃ² nhÃºng á»›t vÃ  gÃ¢n bÃ² chÃ¡y tá»i Äƒn cÅ©ng ngon Ä‘Ã³.', '0.000', 'mockhoa.jpg', '2016-11-27 09:39:37', 15, 'Moc khoa handmade M9'),
(89, 3, 'DÃ¢y chuyá»n handmade D9', '255.000', '[Háº¹n hÃ² vá»›i "TRÃ€ Sá»®A Háº T SIÃŠU KHá»¦NG" bÃ©o bÃ©o - DeliveryNow - Ship táº­n nÆ¡i]\r\nCuá»‘i tuáº§n nÃ y dÃ nh táº·ng mÃ³n quÃ¡ báº¥t ngá» cho ngÆ°á»i áº¥y vá»›i mÃ³n trÃ  sá»¯a háº¡t khá»•ng lá»“, hÃºt bao Ä‘Ã£ nÃ y nhÃ©. Mua háº³n ly to Ä‘á»ƒ cÃ³ Ä‘Æ°á»£c ly nhá»±a cháº¥t lá»« vÃ  2 trÃ¡i tim bÃ© nhá» dá»… thÆ°Æ¡ng gá»­i cho báº¡n áº¥y nhÃ¡.', '35.000', 'daychuyen1.jpg', '2016-11-27 09:40:16', 15, 'Day chuyen handmade D9'),
(90, 4, 'Há»™p quÃ  dá»… thÆ°Æ¡ng H12', '60.000', '[Háº¹n hÃ² vá»›i "TRÃ€ Sá»®A Háº T SIÃŠU KHá»¦NG" bÃ©o bÃ©o - DeliveryNow - Ship táº­n nÆ¡i]\r\nCuá»‘i tuáº§n nÃ y dÃ nh táº·ng mÃ³n quÃ¡ báº¥t ngá» cho ngÆ°á»i áº¥y vá»›i mÃ³n trÃ  sá»¯a háº¡t khá»•ng lá»“, hÃºt bao Ä‘Ã£ nÃ y nhÃ©. Mua háº³n ly to Ä‘á»ƒ cÃ³ Ä‘Æ°á»£c ly nhá»±a cháº¥t lá»« vÃ  2 trÃ¡i tim bÃ© nhá» dá»… thÆ°Æ¡ng gá»­i cho báº¡n áº¥y nhÃ¡.', '0.000', 'hopqua.jpg', '2016-11-27 09:40:40', 35, 'Hop qua de thuong H12'),
(91, 9, 'MÃ³c khÃ³a handmade M10', '32.000', '[Háº¹n hÃ² vá»›i "TRÃ€ Sá»®A Háº T SIÃŠU KHá»¦NG" bÃ©o bÃ©o - DeliveryNow - Ship táº­n nÆ¡i]\r\nCuá»‘i tuáº§n nÃ y dÃ nh táº·ng mÃ³n quÃ¡ báº¥t ngá» cho ngÆ°á»i áº¥y vá»›i mÃ³n trÃ  sá»¯a háº¡t khá»•ng lá»“, hÃºt bao Ä‘Ã£ nÃ y nhÃ©. Mua háº³n ly to Ä‘á»ƒ cÃ³ Ä‘Æ°á»£c ly nhá»±a cháº¥t lá»« vÃ  2 trÃ¡i tim bÃ© nhá» dá»… thÆ°Æ¡ng gá»­i cho báº¡n áº¥y nhÃ¡.', '0.000', 'mockhoa4.jpg', '2016-11-27 09:41:07', 20, 'Moc khoa handmade M10'),
(92, 5, 'Thiá»‡p handmade T9', '54.000', '["6 CHUá»–I COFFEE SHOP" Ä‘a phong cÃ¡ch Ä‘Æ°á»£c yÃªu thÃ­ch nháº¥t SG]\r\nStyle cá»• Ä‘iá»ƒn, bá»¥i báº·m, cÃ¡ tÃ­nh hay lá»™ng láº«y nhÆ° chÃ¢u Ã‚u Ä‘á»u cÃ³ á»Ÿ 6 chuá»—i coffee nÃ y nhÃ©. KhÃ´ng gian chuáº©n khÃ´ng cáº§n chá»‰nh, phe sá»‘ng áº£o note vá» nÃ¨.', '0.000', 'thiep.jpg', '2016-11-27 09:43:49', 24, 'Thiep handmade T9'),
(93, 6, 'DÃ¢y chuyá»n handmade D10', '175.000', '["6 CHUá»–I COFFEE SHOP" Ä‘a phong cÃ¡ch Ä‘Æ°á»£c yÃªu thÃ­ch nháº¥t SG]\r\nStyle cá»• Ä‘iá»ƒn, bá»¥i báº·m, cÃ¡ tÃ­nh hay lá»™ng láº«y nhÆ° chÃ¢u Ã‚u Ä‘á»u cÃ³ á»Ÿ 6 chuá»—i coffee nÃ y nhÃ©. KhÃ´ng gian chuáº©n khÃ´ng cáº§n chá»‰nh, phe sá»‘ng áº£o note vá» nÃ¨.', '0.000', 'daychuyen3.jpeg', '2016-11-27 09:44:09', 24, 'Day chuyen handmade D10'),
(94, 9, 'MÃ³c khÃ³a handmade M11', '55.000', '["6 CHUá»–I COFFEE SHOP" Ä‘a phong cÃ¡ch Ä‘Æ°á»£c yÃªu thÃ­ch nháº¥t SG]\r\nStyle cá»• Ä‘iá»ƒn, bá»¥i báº·m, cÃ¡ tÃ­nh hay lá»™ng láº«y nhÆ° chÃ¢u Ã‚u Ä‘á»u cÃ³ á»Ÿ 6 chuá»—i coffee nÃ y nhÃ©. KhÃ´ng gian chuáº©n khÃ´ng cáº§n chá»‰nh, phe sá»‘ng áº£o note vá» nÃ¨.', '0.000', 'mockhoa3.jpg', '2016-11-27 09:44:28', 15, 'Moc khoa handmade M11'),
(95, 3, 'DÃ¢y chuyá»n handmade D11', '160.000', '["6 CHUá»–I COFFEE SHOP" Ä‘a phong cÃ¡ch Ä‘Æ°á»£c yÃªu thÃ­ch nháº¥t SG]\r\nStyle cá»• Ä‘iá»ƒn, bá»¥i báº·m, cÃ¡ tÃ­nh hay lá»™ng láº«y nhÆ° chÃ¢u Ã‚u Ä‘á»u cÃ³ á»Ÿ 6 chuá»—i coffee nÃ y nhÃ©. KhÃ´ng gian chuáº©n khÃ´ng cáº§n chá»‰nh, phe sá»‘ng áº£o note vá» nÃ¨.', '50.000', 'daychuyen4.jpg', '2016-11-27 09:44:50', 12, 'Day chuyen handmade D11'),
(96, 9, 'MÃ³c khÃ³a handmade M12', '15.000', 'Qua ThÃ¡i lÃ  pháº£i dÃ¹ng má»i thá»§ Ä‘oáº¡n Ä‘á»ƒ kiáº¿m em nÃ y cho báº±ng Ä‘Æ°á»£c, bÃ¡nh hÆ¡i ngá»t táº¹o má» ngon hÃ´ng tÃ i nÃ o táº£ ná»•i, ai Ä‘Ã³ á»Ÿ SG bÃ¡n dÃ¹m Ad Ä‘iii.', '0.000', 'mockhoa2.jpg', '2016-11-27 09:45:47', 30, 'Moc khoa handmade M12'),
(97, 8, 'Äá»“ng há»“ handmade 5', '175.000', 'Qua ThÃ¡i lÃ  pháº£i dÃ¹ng má»i thá»§ Ä‘oáº¡n Ä‘á»ƒ kiáº¿m em nÃ y cho báº±ng Ä‘Æ°á»£c, bÃ¡nh hÆ¡i ngá»t táº¹o má» ngon hÃ´ng tÃ i nÃ o táº£ ná»•i, ai Ä‘Ã³ á»Ÿ SG bÃ¡n dÃ¹m Ad Ä‘iii.', '0.000', 'dongho5.jpg', '2016-11-27 09:46:11', 15, 'dong ho handmade 5'),
(98, 3, 'Thiá»‡p handmade T10', '60.000', 'Qua ThÃ¡i lÃ  pháº£i dÃ¹ng má»i thá»§ Ä‘oáº¡n Ä‘á»ƒ kiáº¿m em nÃ y cho báº±ng Ä‘Æ°á»£c, bÃ¡nh hÆ¡i ngá»t táº¹o má» ngon hÃ´ng tÃ i nÃ o táº£ ná»•i, ai Ä‘Ã³ á»Ÿ SG bÃ¡n dÃ¹m Ad Ä‘iii.', '10.000', 'thiep1.JPG', '2016-11-27 09:46:42', 10, 'Thiep handmade T10'),
(99, 8, 'Äá»“ng há»“ handmade 6', '199.000', 'Qua ThÃ¡i lÃ  pháº£i dÃ¹ng má»i thá»§ Ä‘oáº¡n Ä‘á»ƒ kiáº¿m em nÃ y cho báº±ng Ä‘Æ°á»£c, bÃ¡nh hÆ¡i ngá»t táº¹o má» ngon hÃ´ng tÃ i nÃ o táº£ ná»•i, ai Ä‘Ã³ á»Ÿ SG bÃ¡n dÃ¹m Ad Ä‘iii.', '0.000', 'dongho2.jpg', '2016-11-27 09:47:50', 15, 'dong ho handmade 6'),
(100, 8, 'Äá»“ng há»“ handmade 7', '255.000', 'Má»›i ra máº¯t thÃ´i mÃ  mÃ³n gÃ  rÃ¡n ÄÃ i Loan siÃªu khá»§ng nÃ y Ä‘Ã£ hot quÃ¡ trá»i. GÃ  rÃ¡n giÃ²n Ä‘á»u vÃ  cÃ³ Ä‘á»§ cÃ¡c loáº¡i "topping" hÆ°Æ¡ng vá»‹ tha há»“ cho cÃ¡c báº¡n lá»±a chá»n theo sá»Ÿ thÃ­ch luÃ´n nÃ¨. MÃ¬nh thÃ­ch thÃ¬ click liá»n luÃ´n nÃ¨!', '0.000', 'dongho3.jpg', '2016-11-27 09:48:18', 15, 'dong ho handmade 7'),
(101, 6, 'DÃ¢y chuyá»n handmade D12', '135.000', 'Má»›i ra máº¯t thÃ´i mÃ  mÃ³n gÃ  rÃ¡n ÄÃ i Loan siÃªu khá»§ng nÃ y Ä‘Ã£ hot quÃ¡ trá»i. GÃ  rÃ¡n giÃ²n Ä‘á»u vÃ  cÃ³ Ä‘á»§ cÃ¡c loáº¡i "topping" hÆ°Æ¡ng vá»‹ tha há»“ cho cÃ¡c báº¡n lá»±a chá»n theo sá»Ÿ thÃ­ch luÃ´n nÃ¨. MÃ¬nh thÃ­ch thÃ¬ click liá»n luÃ´n nÃ¨!', '0.000', 'daychuyen.jpg', '2016-11-27 09:48:49', 25, 'Day chuyen handmade D12'),
(102, 7, 'VÃ²ng tay vintage V10', '99.000', 'Má»›i ra máº¯t thÃ´i mÃ  mÃ³n gÃ  rÃ¡n ÄÃ i Loan siÃªu khá»§ng nÃ y Ä‘Ã£ hot quÃ¡ trá»i. GÃ  rÃ¡n giÃ²n Ä‘á»u vÃ  cÃ³ Ä‘á»§ cÃ¡c loáº¡i "topping" hÆ°Æ¡ng vá»‹ tha há»“ cho cÃ¡c báº¡n lá»±a chá»n theo sá»Ÿ thÃ­ch luÃ´n nÃ¨. MÃ¬nh thÃ­ch thÃ¬ click liá»n luÃ´n nÃ¨!', '0.000', 'vongtay5.jpg', '2016-11-27 09:49:15', 25, 'Vong tay vintage V10'),
(103, 5, 'Thiá»‡p handmade T11', '50.000', 'Má»›i ra máº¯t thÃ´i mÃ  mÃ³n gÃ  rÃ¡n ÄÃ i Loan siÃªu khá»§ng nÃ y Ä‘Ã£ hot quÃ¡ trá»i. GÃ  rÃ¡n giÃ²n Ä‘á»u vÃ  cÃ³ Ä‘á»§ cÃ¡c loáº¡i "topping" hÆ°Æ¡ng vá»‹ tha há»“ cho cÃ¡c báº¡n lá»±a chá»n theo sá»Ÿ thÃ­ch luÃ´n nÃ¨. MÃ¬nh thÃ­ch thÃ¬ click liá»n luÃ´n nÃ¨!', '0.000', 'thiep2.jpg', '2016-11-27 09:50:16', 15, 'Thiep handmade T11'),
(104, 5, 'Thiá»‡p Ä‘á»™c Ä‘Ã¡o 1', '80.000', 'Tá»« khÃºc nÃ y mÃ  nhÃ¬n xuá»‘ng dÃ n hoa mai anh Ä‘Ã o Ä‘áº¹p rung rinh luÃ´n á»›, chá»¥p hÃ¬nh cÅ©ng dá»… ná»¯a, bon chen dÆ°á»›i mÃ­ chá»— kia chi cho má»£t.', '0.000', 'thiep.jpg', '2016-11-27 09:50:45', 35, 'Thiep doc dao 1');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` bigint(20) NOT NULL,
  `trangthai` tinyint(4) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `customer_phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `customer_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `customer_address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(15,3) NOT NULL DEFAULT '0.000',
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_product`
--
ALTER TABLE `order_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `order_product`
--
ALTER TABLE `order_product`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
