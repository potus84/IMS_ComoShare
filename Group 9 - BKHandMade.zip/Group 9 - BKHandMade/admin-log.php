<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>HANDMADE BK | ADMIN | LOG IN</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    
    <style>

      * {
      -moz-box-sizing: border-box;
      box-sizing: border-box;
      }

      body {
        background: #404040;
        font: 100%/1 "Helvetica Neue", Arial, sans-serif;
      }

      .login {
        position: absolute;
        top: 50%;
        left: 50%;
        margin: -10rem 0 0 -10rem;
        width: 30rem;
        height: 30rem;
        padding: 20px;
        background: #fff;
        border-radius: 5px;
        overflow: hidden;
      }

      .login-header {
        position: absolute;
        left: 0;
        top: 0;
        z-index: 1;
        width: 4rem;
        height: 30rem;
        background: orange;
        transition: width 0.5s ease-in-out;
      }
      .login-header > .text {
        display: block;
        width: 100%;
        height: 100%;
        font-size: 1rem;
        text-align: center;
        line-height: 20rem;
        color: #fff;
        transition: all 0.5s ease-in-out;
        transform: rotate(-90deg);
      }

      .login-form {
        margin: 0 0 0 2rem;
        padding: 0.5rem;
      }

      .login-input {
        display: block;
        width: 100%;
        font-size: 2.5rem;
        padding: 1rem 1.5rem;
        box-shadow: none;
        border-color: #ccc;
        border-width: 0 0 2px 0;
      }
      .login-input + .login-input {
        margin: 10px 0 0;
      }
      .login-input:focus {
        outline: none;
        border-bottom-color: orange;
      }

      .login-btn {
        position: absolute;
        right: 1rem;
        bottom: 1rem;
        width: 5rem;
        height: 5rem;
        border: none;
        background: orange;
        border-radius: 50%;
        font-size: 0;
        border: 0.6rem solid transparent;
        transition: all 0.3s ease-in-out;
        cursor: pointer;
      }
      .login-btn:after {
        content: "";
        position: absolute;
        left: 1rem;
        top: 0.8rem;
        width: 0;
        height: 0;
        border-left: 2.4rem solid #fff;
        border-top: 1.2rem solid transparent;
        border-bottom: 1.2rem solid transparent;
        transition: border 0.3s ease-in-out 0s;
      }
      .login-btn:hover, .login-btn:focus, .login-btn:active {
        background: #fff;
        border-color: orange;
        outline: none;
      }
      .login-btn:hover:after, .login-btn:focus:after, .login-btn:active:after {
        border-left-color: orange;
      }

    </style>
    
  </head>

  <body>
  
    <div class="login">
      <header class="login-header"><span class="text">LOGIN</span></header>
      <form class="login-form" method="POST">
        <input type="text" name="username" placeholder="Username" class="login-input"/>
        <input type="password" name="password" placeholder="Password" class="login-input"/>
        <button type="submit" name="login" class="login-btn">login</button>
      </form>
    </div>

    <?php 
      include_once('config.php');

      try {
        if (isset($_POST['login'])) {
          $error_login = "";

          $username = $_POST['username'];
          $password = $_POST['password'];
          
          $check_user = $conn->prepare("SELECT username FROM admin");
          $check_user->setFetchMode(PDO::FETCH_ASSOC); 
          $check_user->execute();
          while($row = $check_user->fetch()) {
            if ($username == $row['username']) {
              $check_password = $conn->prepare("SELECT password FROM admin WHERE username='$username'");
              $check_password->setFetchMode(PDO::FETCH_ASSOC); 
              $check_password->execute();
              while($pass = $check_password->fetch()) {
                if (md5($password) == $pass['password']) {
                  session_start();
                  $_SESSION['admin'] = $username;
                  header('Location: admin.php');
                  break;
                }
              }
              $error_login = "<p>Sai mật khẩu!</p>";
              break;
            }
          }
          if ($error_login == "") $error_login = "<p>Tên đăng nhập không tồn tại</p>";

          if ($error_login != "") {
            echo "<div class='alert alert-danger' style='font-size: 15px'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <strong>Có lỗi xảy ra!</strong>" .$error_login ."</div>";
          }
        }
      }
      catch (PDOException $e) {
        echo "ERROR! Co loi xay ra voi PDO";
        echo $e->getMessage();
        exit();
      }
    ?>
    

    <script src='js/jquery-3.1.0.min.js'></script>  
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script> 
  </body>
</html>
