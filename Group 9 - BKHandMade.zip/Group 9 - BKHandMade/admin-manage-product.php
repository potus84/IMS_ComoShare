<?php 
	include_once 'config.php';
	session_start();
	if (!isset($_SESSION['admin'])) {
		header('Location: admin-log.php');
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>Admin Manage Product</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="DataTables-1.10.12/media/css/dataTables.bootstrap.css">

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/admin-manage.css">
    <link rel="stylesheet" href="css/admin-manage-product.css">


  </head>

  <body>
	<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="admin.php">Admin Site</a>
			</div>
	
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Xin chào <?php echo $_SESSION['admin'] ?><b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><form method="POST">
								<button type="submit" name="logout-btn" class="btn btn-link">Đăng xuất</button>
							</form></li>
						</ul>
					</li>
				</ul>
			</div><!-- /.navbar-collapse -->
		</div>
	</nav>
	<!-- /navbar -->
	<?php 
		if (isset($_POST['logout-btn'])) {
			unset($_SESSION['admin']);
			echo "<script>window.location.replace('admin-log.php');</script>";
		}
	?>


	<div class="wrapper container-fluid">
		<div class="sidebar col-sm-3 col-md-2">
			<ul>
				<li><a href="admin-manage-admin.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý admin</a>
        		</li>
				<li><a href="admin-manage-member.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý thành viên</a>
				</li>
				<li><a href="admin-manage-product.php"><span><i class="fa fa-briefcase" aria-hidden="true"></i></span>Quản lý sản phẩm</a></li>
				<li><a href="admin-manage-bill.php"><span><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>Quản lý đơn hàng</a></li>
			</ul>
		</div>
		<!-- /sidebar -->
		<div class="content manage-product col-sm-9 col-md-10">
			<h1>QUẢN LÝ SẢN PHẨM</h1>
			<a class="btn btn-add-member" data-toggle="modal" href='#modal-add-product'>Thêm sản phẩm</a>
			<div class="modal fade" id="modal-add-product">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h2 class="modal-title">Thêm sản phẩm</h2>
						</div>
						<div class="modal-body">
							<form action="" method="POST" role="form">
								<div class="form-group">									
									<div class="input-field">
										<label for="">Tên sản phẩm</label>
										<input type="text" class="form-control" name="add_product_name" required>
									</div>
									<div class="input-field">
										<label for="">Giá bán</label>
										<input type="text" class="form-control" name="add_product_gia" required>
									</div>
									<div class="input-field">
										<label for="">Khuyến mãi</label>
										<input type="text" class="form-control" name="add_product_km" required>
									</div>
									<div class="input-field">
										<label for="">Mô tả chi tiết</label>
										<textarea class="form-control" rows="10" name="add_product_mota" required></textarea>
									</div>	
									<div class="input-field">
										<label for="">Số lượng</label>
										<input type="number" class="form-control" name="add_product_quant" required>
									</div>
									<div class="input-field">
										<label for="">Danh mục</label>
										<select name="add_product_category" id="add_product_category" class="form-control" required>
											<option value="4">Hộp Quà</option>
											<option value="5">Thiệp</option>
											<option value="6">Dây Chuyền</option>
											<option value="7">Vòng Tay</option>
											<option value="8">Đồng Hồ</option>
											<option value="9">Móc Khóa</option>
											<option value="3">Khuyến Mãi</option>
										</select>
									</div>
									<div class="input-field ft-img">
										<label for="">Ảnh sản phẩm</label>
										<input type="file" name="add_product_img" id="add_product_img" required="required" onchange="setPreview()" >
										<div class="preview-ft-img"></div>
									</div>
									<div class="form-footer">
										<button type="button" class="btn btn-cancle-form" data-dismiss="modal">Hủy</button>
										<button type="submit" class="btn btn-save-form" name="add_product_btn">Tạo</button>
									</div>
								</div>	
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /modal-create -->
		<?php 
			function convert_vi_to_en($str) {
		      // In thường
	           $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
	           $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
	           $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
	           $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
	           $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
	           $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
	           $str = preg_replace("/(đ)/", 'd', $str);    
	      // In đậm
	           $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'a', $str);
	           $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'e', $str);
	           $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'i', $str);
	           $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'o', $str);
	           $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'u', $str);
	           $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'y', $str);
	           $str = preg_replace("/(Đ)/", 'd', $str);
	           return $str; // Trả về chuỗi đã chuyển
		    } 

			if (isset($_POST['add_product_btn'])) {
				try {
					$add_product = $conn->prepare("INSERT INTO product(catalog_id, name, gia, mota, giamgia, link_anh, date_added, quantity, keyword) VALUES (:catalog_id, :name, :gia, :mota, :giamgia, :link_anh, :date_added, :quantity, :keyword)");

					$add_product->bindParam(':catalog_id', $_POST['add_product_category']);
					$add_product->bindParam(':name', $_POST['add_product_name']);
					$add_product->bindParam(':gia', $_POST['add_product_gia']);
					$add_product->bindParam(':mota', $_POST['add_product_mota']);
					$add_product->bindParam(':giamgia', $_POST['add_product_km']);
					$add_product->bindParam(':link_anh', $_POST['add_product_img']);
					$add_product->bindParam(':date_added', date("Y-m-d h:i:sa"));
					$add_product->bindParam(':quantity', $_POST['add_product_quant']);
					$add_product->bindParam(':keyword', convert_vi_to_en($_POST['add_product_name']));

					$add_product->execute();
					echo "<script>window.location.replace('admin-manage-product.php');</script>";
				}
				catch (PDOException $e) {
					echo "ERROR! Co loi xay ra voi PDO";
					echo $e->getMessage();
					exit();
				}
			}	
			?>


			<div class="modal fade" id="modal-edit-product">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h2 class="modal-title">Thêm sản phẩm</h2>
						</div>
						<div class="modal-body">
							<form action="" method="POST" role="form">
								<div class="form-group">									
									<div class="input-field">
										<label for="">Tên sản phẩm</label>
										<input type="text" class="form-control" id="edit_product_name" required>
									</div>
									<div class="input-field">
										<label for="">Giá bán</label>
										<input type="text" class="form-control" id="edit_product_gia" required>
									</div>
									<div class="input-field">
										<label for="">Khuyến mãi</label>
										<input type="text" class="form-control" id="edit_product_km" required>
									</div>
									<div class="input-field">
										<label for="">Mô tả chi tiết</label>
										<textarea class="form-control" rows="10" id="edit_product_mota" required></textarea>
									</div>	
									<div class="input-field">
										<label for="">Số lượng</label>
										<input type="number" class="form-control" id="edit_product_quant" required>
									</div>
									<div class="input-field">
										<label for="">Danh mục</label>
										<select name="add_product_category" id="edit_product_category" class="form-control" required>
											<option value="4">Hộp Quà</option>
											<option value="5">Thiệp</option>
											<option value="6">Dây Chuyền</option>
											<option value="7">Vòng Tay</option>
											<option value="8">Đồng Hồ</option>
											<option value="9">Móc Khóa</option>
											<option value="3">Khuyến Mãi</option>
										</select>
									</div>
									<div class="input-field ft-img">
										<label for="">Ảnh sản phẩm</label>
										<input type="file" name="add_product_img" id="edit_product_img" required="required" onchange="setPreview()" >
										<div class="preview-ft-img edit-img"></div>
									</div>
									<input type="hidden" id="productID">
									<input type="hidden" id="old_img">
									<div class="form-footer">
										<button type="button" class="btn btn-cancle-form" data-dismiss="modal">Hủy</button>
										<button type="submit" class="btn btn-save-form" name="add_product_btn" onclick="saveProduct()">Lưu</button>
									</div>
								</div>	
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /modal-modified -->


			<h1>Danh sách sản phẩm</h1>
			<table class="list-product">
				<thead>
					<tr>
						<td>ID</td>
						<td>Tên sản phẩm</td>
						<td>Hình ảnh</td>
						<td>Giá</td>
						<td>Khuyến mãi</td>
						<td>Category</td>
						<td>Số lượng</td>
						<td>Sửa</td>
						<td>Xóa</td>
					</tr>
				</thead>
				<tbody>
				<?php 
					try {
						$getProduct = $conn->prepare("SELECT product.id, product.name, product.link_anh, product.gia, product.giamgia, categories.category_name, product.quantity FROM product INNER JOIN categories ON product.catalog_id = categories.category_id");	
						$getProduct->setFetchMode(PDO::FETCH_ASSOC);
						$getProduct->execute();
						while ($row = $getProduct->fetch()) {
							$product_row = "<tr>";
							$product_row .= "<td>" . $row['id'] . "</td>";
							$product_row .= "<td>" . $row['name'] . "</td>";
							$product_row .= "<td><img src='images/" . $row['link_anh'] . "' width='50' alt='" . $row['name'] . "'></td>";
							$product_row .= "<td>" . $row['gia'] . "</td>";
							$product_row .= "<td>" . $row['giamgia'] . "</td>";
							$product_row .= "<td>" . $row['category_name'] . "</td>";
							$product_row .= "<td>" . $row['quantity'] . "</td>";
							$product_row .= "<td><button type='button' class='btn btn-warning' onclick='editProduct(" .$row['id']. ")'>Edit</button></td>";
							$product_row .=  "<td><button type='button' class='btn btn-danger' onclick='deleteProduct(" .$row['id']. ")'>Delete</button></td>";
							$product_row .= "</tr>";
							echo $product_row;
						}
					}
					catch (PDOException $e) {
						echo "ERROR! Co loi xay ra voi PDO";
						echo $e->getMessage();
						exit();
					}
				?>	
				</tbody>
				
			</table>

		</div>

		<!-- /content -->

	</div>
	<!-- /wrapper -->
	
	<div class="footer container-fluid">
		<p>&copy; 2016 by HCMUT</p>
	</div>
	<!-- /footer -->

	<!-- Script -->
    <!-- <script src="jquery-3.1.0.min.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="DataTables-1.10.12/media/js/jquery.dataTables.js"></script>
    <!-- <script src="bootstrap-material-design-master/dist/js/material.min.js"></script> -->
    <script>
    	$(document).ready(function() {
		    $('.list-product').DataTable();
		} );

		function setPreview() {
			var getImagePath = URL.createObjectURL(event.target.files[0]);
		 	$('.manage-product .form-group .ft-img .preview-ft-img').css('background-image', 'url(' + getImagePath + ')');
		}

		function editProduct(id) {
			$('#productID').val(id);

			$.post(
		        'ajax/editProduct.php',
		        {
		            id: id
		        },
		        function (data, status) {
		            var product = JSON.parse(data);
		            $("#edit_product_name").val(product.name);
		            $("#edit_product_gia").val(product.gia);
		            $("#edit_product_km").val(product.giamgia);
		            $("#edit_product_mota").val(product.mota);
		            $("#edit_product_quant").val(product.quantity);
		            $("#edit_product_category").val(product.catalog_id);
		            $("#old_img").val(product.link_anh);
		            $('.edit-img').css('background-image', 'url(images/' + product.link_anh + ')');
		        }
		    );
		    $("#modal-edit-product").modal("show");
		}

		function saveProduct() {
			var id_to_edit = $('#productID').val();
			var edit_product_name = $('#edit_product_name').val();
			var edit_product_gia = $("#edit_product_gia").val();
            var edit_product_km = $("#edit_product_km").val();
            var edit_product_mota = $("#edit_product_mota").val();
            var edit_product_quant = $("#edit_product_quant").val();
            var edit_product_category = $("#edit_product_category").val();
            if ($('#edit_product_img').val().replace(/C:\\fakepath\\/i, '') != '')
            	var edit_product_img = $('#edit_product_img').val().replace(/C:\\fakepath\\/i, '');
            else
            	var edit_product_img = $("#old_img").val();
		  
		    $.post(
		        'ajax/saveProduct.php',
		        {
		            id_to_edit: id_to_edit,
		            edit_product_name: edit_product_name,
					edit_product_gia: edit_product_gia, 
					edit_product_km: edit_product_km,
					edit_product_mota: edit_product_mota,
					edit_product_quant: edit_product_quant,
					edit_product_category: edit_product_category,
					edit_product_img: edit_product_img
		        },
		        function (data, status) {
		            if (data != '') {
		                alert(data);
		            }
		            else {
		                $("#modal-edit-product").modal("hide");
		                location.reload();
		            }
		        });
		}

		function deleteProduct(id) {
			var x = confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');
		    if (x == true) {
		        $.post(
		            'ajax/deleteProduct.php',
		            {
		                id: id
		            },
		            function(data, status) {
		                location.reload();
		            }
		        );
		    }
		}
		
    </script>
    
  </body>
</html>







