<?php 
  include_once 'config.php';
  session_start();
  if (!isset($_SESSION['admin'])) {
    header('Location: admin-log.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>Admin Manage Member</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="DataTables-1.10.12/media/css/dataTables.bootstrap.css">

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/admin-manage.css">
    <link rel="stylesheet" href="css/admin-manage-member.css">

  <script src="js/jquery-3.1.0.min.js"></script>
  </head>

  <body>
  <nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="admin.php">Admin Site</a>
      </div>
  
      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Xin chào <?php echo $_SESSION['admin'] ?><b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><form method="POST">
                <button type="submit" name="logout-btn" class="btn btn-link">Đăng xuất</button>
              </form></li>
            </ul>
          </li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div>
  </nav>
  <!-- /navbar -->
  <?php 
    if (isset($_POST['logout-btn'])) {
      unset($_SESSION['admin']);
      echo "<script>window.location.replace('admin-log.php');</script>";
    }
  ?>


  <div class="wrapper container-fluid">
    <div class="sidebar col-sm-3 col-md-2">
      <ul>

        <li><a href="admin-manage-admin.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý admin</a>
        </li>
        <li><a href="admin-manage-member.php"><span><i class="fa fa-user" aria-hidden="true"></i></span>Quản lý thành viên</a>
        </li>
        <li><a href="admin-manage-product.php"><span><i class="fa fa-briefcase" aria-hidden="true"></i></span>Quản lý sản phẩm</a></li>
        <li><a href="admin-manage-bill.php"><span><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>Quản lý đơn hàng</a></li>
      </ul>
    </div>
    <!-- /sidebar -->
    <div class="content manage-member col-sm-9 col-md-10">
      <h1>QUẢN LÝ THÀNH VIÊN</h1>
      <div class="modal fade" id="modal-add-admin">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <!-- <h2 class="modal-title">Thêm admin</h2> -->
            </div>
            <div class="modal-body">
              <?php 
                  if (isset($_POST['admin-add-btn'])) {
                    $admin_username = $_POST['admin-username-register'];
                    $admin_password = $_POST['admin-password-register'];
                    $admin_password_confirm = $_POST['admin-password-confirmation'];

                    $error_register_admin = "";

                    if (strlen($admin_username) < 5) {
                      $error_register_admin .= "<p>Username chứa tối thiểu 5 ký tự!</p>";
                    }
                    elseif (strlen($admin_password) < 6) {
                      $error_register_admin .= "<p>Mật khẩu chứa tối thiểu 6 ký tự!</p>";
                    }
                    elseif ($admin_password != $admin_password_confirm) {
                      $error_register_admin .= "<p>Nhập lại mật khẩu không đúng!</p>";
                    }
                    else {
                      $check_admin_exist = $conn->prepare("SELECT username FROM admin");
                      $check_admin_exist->setFetchMode(PDO::FETCH_ASSOC); 
                      $check_admin_exist->execute();
                      while($row = $check_admin_exist->fetch()) {
                          if ($admin_username == $row['username']) {
                            $error_register_admin .= "<p>Username đã tồn tại!</p>";
                            break;
                          }
                      }
                    }

                    if ($error_register_admin != "") {
                      echo "<script>$( document ).ready(function() {
                        $('#modal-add-admin').modal('show');
                      });</script>";
                  echo "<div class='alert alert-danger'>
                          <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                          <strong>Có lỗi xảy ra!</strong>" .$error_register_admin ."</div>";
                    }      
                    else {
                      try {
                        $add_admin = $conn->prepare("INSERT INTO admin (username, password) 
                                                    VALUES (:username, :password)");

                        $add_admin->bindParam(':username', $admin_username);
                        $add_admin->bindParam(':password', md5($admin_password));
                        $add_admin->execute();

                        echo "<script>alert('Thêm admin thành công!');</script>";
                        echo "<script>window.location.replace('admin-manage-member.php');</script>";
                        
                      }
                      catch (PDOException $e) {
                        echo "ERROR! Co loi xay ra voi PDO";
                        echo $e->getMessage();
                        exit();
                      } 
                    }    
                  }
                  ?>
              <form method="POST" role="form">
                <div class="row">
                  <div class="col-sm-8 col-sm-offset-2">
                    <div class="form-group">
                      <div class="form-group">
                              <label for="username">Username</label>
                              <input type="text" name="admin-username-register" class="form-control" placeholder="Username của admin tối thiểu 5 ký tự" required>
                            </div>

                            <div class="form-group">
                              <label for="password">Mật khẩu</label>
                              <input type="password" name="admin-password-register" class="form-control" placeholder="Tối thiểu 6 ký tự" required>
                            </div>

                            <div class="form-group">
                              <label for="password">Nhập lại mật khẩu</label>
                              <input type="password" name="admin-password-confirmation" placeholder="Tối thiểu 6 ký tự" class="form-control" required>
                            </div>  
                      <div class="form-footer">
                        <button type="button" class="btn btn-cancle-form" data-dismiss="modal">Hủy</button>
                        <button type="submit" name="admin-add-btn" class="btn btn-save-form">Tạo</button>
                      </div>
                    </div>
                  </div>
                </div>                
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- /modal-create-admin -->

      <!--  -->

      <h1>Danh sách khách hàng</h1>
      <a class="btn btn-add-member" data-toggle="modal" href='#modal-add-customer'>Thêm khách hàng</a>
      <div class="modal fade" id="modal-add-customer">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h2 class="modal-title">Thêm khách hàng</h2>
            </div>
            <div class="modal-body">
              <?php 
                  if (isset($_POST['customer-add-btn'])) {
                    $customer_email = $_POST['customer-email-register'];
                    $customer_password = $_POST['customer-password-register'];
                    $customer_password_confirm = $_POST['customer-password-confirmation'];

                    $error_register_customer = "";

                    if (!filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
                      $error_register_customer .= "<p>Địa chỉ email sai định dạng!</p>";
                    }
                    elseif (strlen($customer_password) < 6) {
                      $error_register_customer .= "<p>Mật khẩu chứa tối thiểu 6 ký tự!</p>";
                    }
                    elseif ($customer_password != $customer_password_confirm) {
                      $error_register_customer .= "<p>Nhập lại mật khẩu không đúng!</p>";
                    }
                    else {
                      $check_customer_exist = $conn->prepare("SELECT email FROM customer");
                      $check_customer_exist->setFetchMode(PDO::FETCH_ASSOC); 
                      $check_customer_exist->execute();
                      while($row_cus = $check_customer_exist->fetch()) {
                          if ($customer_email == $row_cus['email']) {
                            $error_register_customer .= "<p>Địa chỉ email đã tồn tại!</p>";
                            break;
                          }
                      }
                    }

                    if ($error_register_customer != "") {
                      echo "<script>$( document ).ready(function() {
                        $('#modal-add-customer').modal('show');
                      });</script>";
                  echo "<div class='alert alert-danger'>
                          <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                          <strong>Có lỗi xảy ra!</strong>" .$error_register_customer ."</div>";
                    }      
                    else {
                      try {
                        $add_customer = $conn->prepare("INSERT INTO customer (email, password, fullname, address, phonenumber) 
                                                    VALUES (:email, :password, :fullname, :address, :phonenumber)  'setname utf-8'");

                        $add_customer->bindParam(':email', $customer_email);
                        $add_customer->bindParam(':fullname', $fullname);
                        $add_customer->bindParam(':address', $address);
                        $add_customer->bindParam(':phonenumber', $phonenumber);
                        $add_customer->bindParam(':password', md5($customer_password));
                        $add_customer->execute();

                        echo "<script>alert('Thêm khách hàng thành công!');</script>";
                        echo "<script>window.location.replace('admin-manage-member.php');</script>";
                        
                      }
                      catch (PDOException $e) {
                        echo "ERROR! Co loi xay ra voi PDO";
                        echo $e->getMessage();
                        exit();
                      } 
                    }    
                  }
                  ?>
              <form method="POST" role="form">
                <div class="row">
                  <div class="col-sm-8 col-sm-offset-2">
                    <div class="form-group">
                            <div class="form-group">
                              <label for="email">Email</label>
                              <input type="email" name="customer-email-register" class="form-control" placeholder="Địa chỉ email của khách hàng" required>
                            </div>
                            <div class="form-group">
                              <label for="fullname">Họ và tên</label>
                              <input type="text" name="fullname" class="form-control" placeholder="Tên của khách hàng" required>
                            </div>
                            <div class="form-group">
                              <label for="address">Địa chỉ</label>
                              <input type="text" name="address" class="form-control" placeholder="Địa chỉ của khách hàng" required>
                            </div>
                            <div class="form-group">
                              <label for="phonenumber">Sđt</label>
                              <input type="text" name="phonenumber" class="form-control" placeholder="Số điện thoại của khách hàng" required>
                            </div>
                            <div class="form-group">
                              <label for="password">Mật khẩu</label>
                              <input type="password" name="customer-password-register" class="form-control" placeholder="Tối thiểu 6 ký tự" required>
                            </div>

                            <div class="form-group">
                              <label for="password">Nhập lại mật khẩu</label>
                              <input type="password" name="customer-password-confirmation" placeholder="Tối thiểu 6 ký tự" class="form-control" required>
                            </div>  
                      <div class="form-footer">
                        <button type="button" class="btn btn-cancle-form" data-dismiss="modal">Hủy</button>
                        <button type="submit" name="customer-add-btn" class="btn btn-save-form">Tạo</button>
                      </div>
                    </div>
                  </div>
                </div>                
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- /modal-create-customer -->
      <table class="list-member">
        <thead>
          <tr>
            <td>ID</td>
            <td>Email</td>
            <td>Họ và tên</td>
            <td>Địa chỉ</td>
            <td>Sđt</td>
            <td>Xóa</td>
          </tr>
        </thead>
        <tbody>
        <?php 
          $get_cusomter = $conn->prepare("SELECT * FROM customer");
          $get_cusomter->setFetchMode(PDO::FETCH_ASSOC);
          $get_cusomter->execute();
          while ($customer_record = $get_cusomter->fetch()) {
            $customer_row = "<tr>";
            $customer_row .= "<td>" . $customer_record['id'] . "</td>";
            $customer_row .= "<td>" . $customer_record['email'] . "</td>";
            $customer_row .= "<td>" . $customer_record['fullname'] . "</td>";
            $customer_row .= "<td>" . $customer_record['address'] . "</td>";
            $customer_row .= "<td>" . $customer_record['phonenumber'] . "</td>";
            $customer_row .=  "<td><button type='button' class='btn btn-danger' onclick='deleteCustomer(" .$customer_record['id']. ")'>Delete</button></td>";
            $customer_row .= "</tr>";
            echo $customer_row;
          } 
        ?>
        </tbody>
        
      </table>

    </div>

    <!-- /content -->

  </div>
  <!-- /wrapper -->
  
  <div class="footer container-fluid">
    <p>&copy; 2016 by HCMUT</p>
  </div>
  <!-- /footer -->

  <!-- Script -->
    <!-- <script src="jquery-3.1.0.min.js"></script> -->
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="DataTables-1.10.12/media/js/jquery.dataTables.js"></script>
    <!-- <script src="cdn.datatables.net/responsive/2.1.0/js/dataTables.responsive.js"></script> -->
    <!-- <script src="bootstrap-material-design-master/dist/js/material.min.js"></script> -->
    <script>
    
      $('.list-member').DataTable();

      function deleteAdmin(id) {
      var x = confirm('Bạn có chắc chắn muốn xóa admin này?');
        if (x == true) {
            $.post(
                'ajax/deleteAdmin.php',
                {
                    id: id
                },
                function(data, status) {
                    location.reload();
                }
            );
        }
    }

    function deleteCustomer(id) {
      var x = confirm('Bạn có chắc chắn muốn xóa khách hàng này?');
        if (x == true) {
            $.post(
                'ajax/deleteCustomer.php',
                {
                    id: id
                },
                function(data, status) {
                    location.reload();
                }
            );
        }
    }
    
    </script>
    
  </body>
</html>







