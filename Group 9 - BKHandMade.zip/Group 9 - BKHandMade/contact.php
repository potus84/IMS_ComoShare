<?php 
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>Liên hệ chúng tôi</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="Swiper-3.3.1/dist/css/swiper.min.css">
    
    <link rel="stylesheet" href="css/index.css"> 
    <link rel="stylesheet" href="css/contact.css">
       
   
  </head>

  
  <body>
  	<?php 
      include('header.php');
    ?>
    <!-- /header -->
    <div class="menu-wrap container-fluid">
      <nav class="menu clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php" class="active">Liên Hệ</a></li>
          </ul>
</nav>
      <a href="index.php" class="toggle-menu"><i class="fa fa-bars" aria-hidden="true"></i></a>
      <nav class="menu-mobile clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php">Liên Hệ</a></li>
          </ul>
      </nav>
    </div>
  <!-- content-here -->
	<div class="content container-fluid">
    <div class="contact"><!-- contact -->
      <h2>Liên hệ với chúng tôi! </h2>
    </div><!-- /contact -->
  <!-- <div class="col-sm-2">
      
    </div> -->
    <div class="infomaps col-sm-7"><!-- infomaps -->
        <div class="maps">
         <iframe src="https://www.google.com/maps/d/u/0/embed?mid=1b2qjNNbMJFBzTxOmrLLNwBmPxDs" class="mapsiframe" id="mapsiframe"></iframe>
        </div>  

    </div><!-- /infomaps -->
    <div class="infocontact col-sm-5" id="infocontact"><!-- infocontact -->      
        <form class="forminfocontact" method="POST">
          <div>
            <label for="username-contact">Tên của bạn</label><br/>
           <!--  <input type="text" name="username" id="username-contact" required=""> -->
            <input type="text" name="username" id="username-contact" class="form-control" value="" required="required">
          </div>
          <div>
            <label for="emailcontact">Thư điện tử</label><br/>
            <!-- <input type="text" name="email" id="emailcontact" required=""> -->
             <input type="text" name="email" id="emailcontact" class="form-control" value="" required="required">
          </div>
          <div>
            <label for="phonecontact">Số điện thoại</label><br/>
            <!-- <input type="text" name="phone" id="phonecontact" required=""> -->
             <input type="text" name="phone" id="phonecontact" class="form-control" value="" required="required">
          </div>
          <div>
            <label for="phonecontact">Lời nhắn của bạn</label><br/>
            <textarea name="phonecontact" id="input" class="form-control" rows="5" required="required"></textarea>
          </div>
          <div>
            <label for="capchacontact">Nhập văn bản</label><br/>
            <img src="images/captcha.png" alt="capcha">
            <!-- <input type="text" name="capcha" id="capchacontact" required=""> -->
             <input type="text" name="capcha" id="capchacontact" class="form-control" value="" required="required">
          </div>
          <div class="inline-group">
            <input type="checkbox" name="stayin" checked="checked">
            <label>Có,tôi đồng ý chịu trách nhiệm với những gì nêu ở trên.</label>
          </div>
          <input type="submit" name="signin" class="btn btn-primary submit" data-default-text="Gửi" value="Gửi">
        </form>
    </div> <!-- /infocontact -->
  
	</div>
	<!-- /content -->

  <?php 
      include('footer.php');
  ?>
	<!-- Script -->
    <script src="js/jquery-3.1.0.min.js"></script>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="Swiper-3.3.1/dist/js/swiper.min.js"></script>

    <script src="js/main.js"></script>
    
    
    <script>
      $(".toggle-menu").click(function(){
        $(".menu-mobile").toggle();
      });

      var swiper = new Swiper('.swiper-container', {
          pagination: '.swiper-pagination',
          nextButton: '.swiper-button-next',
          prevButton: '.swiper-button-prev',
          paginationClickable: true,
          spaceBetween: 30,
          centeredSlides: true,
          autoplay: 2500,
          loop: true,
          autoplayDisableOnInteraction: false
      });

      $("a[href='#top']").click(function() {
         $("html, body").animate({ scrollTop: 0 }, "slow");
         return false;
      });

      $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#go-top').fadeIn();
        } else {
            $('#go-top').fadeOut();
        }
      });

    </script>
    <script type="text/javascript">
      $( document ).ready(function() {
    document.getElementById("mapsiframe").style.height = document.getElementById("infocontact").offsetHeight-20+ "px";

});
    </script>
  </body>
</html>







