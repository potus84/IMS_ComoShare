<?php 
  include_once('config.php');
  session_start();
?>

<!DOCTYPE html>
<html lang="vi">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>Giỏ hàng</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="Swiper-3.3.1/dist/css/swiper.min.css">
    <link rel="stylesheet" href="bootstrap-star-rating/css/star-rating.css">
    <link rel="stylesheet" href="bootstrap-star-rating/themes/krajee-svg/theme.css">

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/cart.css">

    <script src="js/jquery-3.1.0.min.js"></script>
  </head>

  <body>
  
    <?php 
      include('header.php');
    ?>
    <!-- /header -->
    <div class="menu-wrap container-fluid">
      <nav class="menu clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php">Liên Hệ</a></li>
          </ul>
</nav>
      <a href="index.php" class="toggle-menu"><i class="fa fa-bars" aria-hidden="true"></i></a>
      <nav class="menu-mobile clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php">Liên Hệ</a></li>
          </ul>
      </nav>
    </div>
  
  <?php 
    if (!isset($_SESSION['user_email'])) { ?>
      <div class="content container">
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3">
            <div class="alert alert-warning">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <strong>Bạn chưa đăng nhập!</strong>
              <p>Mời bạn <a href="" data-toggle="modal" data-target="#myModal">đăng nhập</a> để có thể xem giỏ hàng.</p>
              <p>Nếu chưa có tài khoản, bạn có thể đăng ký tài khoản <a href="register.php">tại đây.</a></p>
            </div>
          </div>
        </div>
      </div>
    
    <?php }
    else { 
      if ($number_of_item > 0) { ?> 
        <div class="content container clearfix">
      <!-- <img src="images/cart.png" alt="cart" style="width: 70px; margin: 20px 20px 30px 0;"> -->

      <h3 style="font-weight: bold; margin-bottom: 30px;"> Thông tin giỏ hàng</h3>
      <?php 
        $cus_id = $_SESSION['user_id'];
        $stmt_cart_info = $conn->prepare("SELECT cart.cart_id, product.name, product.gia, product.link_anh, product.giamgia, cart.soluong FROM cart INNER JOIN customer ON cart.customer_id = customer.id
                                INNER JOIN product ON cart.product_id = product.id
                                WHERE customer.id='$cus_id'");
        $stmt_cart_info->setFetchMode(PDO::FETCH_ASSOC);
        $stmt_cart_info->execute();
      ?>
      <div class="left-body col-lg-9 col-md-9 col-sm-9 col-xs-12 clearfix">
        <div class="contain-menu clearfix">
          <div class="first col-lg-4 col-md-4 col-sm-4 col-xs-4"><span>Sản phẩm trong giỏ hàng</span> <span class="num"><?php echo $stmt_cart_info->rowCount(); ?></span></div>
          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"><span>Giá</span></div>
          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"><span>Số Lượng</span></div>
          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"><span>Giảm giá</span></div>
          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"><span>Thành tiền</span></div>
        </div>

        <div class="products-space clearfix">

          <?php           
            while($row = $stmt_cart_info->fetch()) {
            ?>
              <div class="product-unit clearfix">
                
                <div class="pro-img col-lg-4 col-md-4 col-sm-4 col-xs-4">
                  <div class="imag imag1" style="background-image:url(images/<?php echo $row['link_anh'] ?>);" ></div>
                <p style="font-weight: bold; padding: 15px 0 0px;"> <?php echo $row['name'] ?> </p>
                <span>
                <?php echo "<button type='button' class='btn btn-link' onclick='deleteItem(" . $row['cart_id'] . ")''>Xóa</button></span>"?>
                </div>
                <div class="pro-price col-lg-2 col-md-2 col-sm-2 col-xs-2">
                  <span class="price-val" style="font-size: 17px; font-weight: bold; color:rgb(255,100,0) "><?php echo $row['gia'] ?></span>
                  <span style="text-decoration: underline;">đ</span>
                </div>
                <div class="pro-num col-lg-2 col-md-2 col-sm-2 col-xs-2">
                  <input type="number" name="num" class="qty-product" min="1" value=<?php echo $row['soluong'] ?> style="width: 50%; text-align: center;">
                  <input type="hidden" class="cart-id" value="<?php echo $row['cart_id'] ?>">
                </div>
                <div class="pro-sale col-lg-2 col-md-2 col-sm-2 col-xs-2">
                <span class="sale-val" style="font-size: 17px; font-weight: bold;"><?php echo $row['giamgia'] ?></span>
                  <span style="text-decoration: underline;">đ</span>
                </div>
                <div class="pro-total col-lg-2 col-md-2 col-sm-2 col-xs-2">
                  <span class="total-val" style="font-size: 17px; font-weight: bold; color:rgb(255,100,0) "></span>
                  <span style="text-decoration: underline;">đ</span>
                </div>
              </div>
            <?php } ?>
        <script>
          $('.qty-product').change(function() {
            var cart_id = $(this).siblings('.cart-id').val();
            var num = $(this).val();
            $.post(
              'ajax/updateNumProduct.php',
              {
                cart_id: cart_id,
                num: num
              }
            );
          });

          function deleteItem(cart_id) {
              var x = confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');
              if (x == true) {
                  $.post(
                      'ajax/deleteItem.php',
                      {
                          cart_id: cart_id
                      },
                      function(data, status) {
                          location.reload();
                      }
                  );
              }
          }
        </script>

        </div>
        <!-- <div class="seemore">
        <a href="#" id="see_more">Xem thêm <i class="fa fa-angle-double-down" aria-hidden="true"></i></a></div> -->
      </div>
      <div class="right-body col-lg-3 col-md-3 col-sm-3 col-xs-12 clearfix">
        <div class="total clearfix">
          <span>Thành tiền:</span>
          <span class="totalmoney">500 000</span>
          <span class="unit">đ</span>
        </div>
        <a href="book.php" class="btn btn-default book">Đặt hàng</a>
        <a href="index.php"  class="btn btn-default cont">Tiếp tục mua hàng</a>
      </div>
        </div>
      <?php 
      }
      else { ?>
        <div class="content container cart0">
          <div class="row">
            <div class="col-sm-8 col-sm-offset-2 text-center">
              <img src="images/cart.png" alt="cart">
              <p class="announce">Giỏ hàng của bạn hiện chưa có sản phẩm nào. Vui lòng thêm sản phẩm vào giỏ hàng.</p>
              <a href="index.php">Tiếp tục mua hàng</a>
            </div>
          </div>
        </div>
  <?php } 
    }
    include('footer.php');
  ?>

  <!-- Script -->
    <!-- <script src="js/jquery-3.1.0.min.js"></script> -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="Swiper-3.3.1/dist/js/swiper.min.js"></script>
    <script src="bootstrap-star-rating/js/star-rating.js"></script>
    <script src="bootstrap-star-rating/themes/krajee-svg/theme.js"></script>
    <script src="bootstrap-star-rating/js/locales/LANG.js"></script>

    <script src="js/main.js"></script>
    
    
    <script>
      $(".toggle-menu").click(function(){
        $(".menu-mobile").toggle();
      });

      var swiper = new Swiper('.swiper-container', {
          pagination: '.swiper-pagination',
          nextButton: '.swiper-button-next',
          prevButton: '.swiper-button-prev',
          paginationClickable: true,
          spaceBetween: 30,
          centeredSlides: true,
          autoplay: 2500,
          loop: true,
          autoplayDisableOnInteraction: false
      });
    </script>

   
    <script type="text/javascript">
      $(function() 
      {
    //----- OPEN
    $('[data-popup-open]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
 
        e.preventDefault();
      });
 
    //----- CLOSE
    $('[data-popup-close]').on('click', function(e)  
      {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
 
        e.preventDefault();
      });
    });
      $(document).mouseup(function (e) 
      {
        if ($('.popup').is(e.target))
            {
               $(".popup").fadeOut(350);
           }
      });

      // $(".menu > ul > li > a").click(function ( e ) {
      //     $(".menu > ul > li > .active").removeClass("active"); //Remove any "active" class  
      //     // $(this).addClass("active"); //Add "active" class to selected tab  
      //     // e.preventDefault();
      //     $(".menu > ul > li > a[href='" + location.pathname.split('/').pop() + "']").addClass('active');

      // });


      // $(".menu .sub-menu li a").click(function ( e ) {
      //     e.preventDefault();
      //     $(".menu .sub-menu li .active").removeClass("active"); //Remove any "active" class  
      //     $(this).addClass("active"); //Add "active" class to selected tab  
      //     $(this).parent().parent().parent().siblings().children('a').removeClass('active')
      //     $(this).parent().parent().parent().children('a').addClass('active');
      // });

      $("a[href='#top']").click(function() {
         $("html, body").animate({ scrollTop: 0 }, "slow");
         return false;
      });

      $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#go-top').fadeIn();
        } else {
            $('#go-top').fadeOut();
        }
      });

      $("#input-id").rating({starCaptions:{}});

     </script>
     <script src="js/jquery-3.1.0.min.js"></script>
    <!-- Script popup for click button delete -->
    <script>
    function myFunctionpopup() {
        var x;
        if (confirm("Bạn muốn xóa sản phẩm này?") == true) {
            x = "You pressed OK!";
        } else {
            x = "You pressed Cancel!";
        }
        document.getElementById("demo").innerHTML = x;
    }

    // function calc_price_item() {
    //   $(".product-unit").each(function() {
    //     var price_val = $('.product-unit .price-val').html();
    //     var sale_val = $('.product-unit .sale-val').html();
    //     var num_item = $('.product-unit .pro-num input', this).val();
    //     var total_val = parseInt(price_val)*parseInt(num_item) - parseInt(sale_val);
    //     $('.product-unit .total-val', this).html(total_val.toString());
    //   });
    // };

    var updateTotal = function() {
 
      var sumtotal;
      var sum = 0;
      //Add each product price to total
      $(".product-unit").each(function() {
          var price = $('.price-val', this).html();
          var quantity = $('.pro-num input', this).val();
          var sale_val = $('.sale-val', this).html();
          //Total for one product
          var subtotal = parseInt(price)*parseInt(quantity) - parseInt(sale_val)*parseInt(quantity);   
          subtotal *= 1000;
          //Display subtotal in HTML element
          $('.total-val', this).html(subtotal.toString());
      });
      // total
      $('.product-unit .total-val').each(function() {
        sum += Number($(this).html());
      }); 
    
      $('.right-body .total .totalmoney').html(sum);
  };

    //Update total when quantity changes
  $('.product-unit .pro-num input').change(function() {
      updateTotal();
  });

  //Update totals when page first loads
  updateTotal();

</script>
  </body>
</html>







