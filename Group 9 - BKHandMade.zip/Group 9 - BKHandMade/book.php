<?php 
  include_once 'config.php';
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/favicon.ico">

    <title>ĐẶT HÀNG</title>

    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="Swiper-3.3.1/dist/css/swiper.min.css">
    <link rel="stylesheet" href="bootstrap-star-rating/css/star-rating.css">
    <link rel="stylesheet" href="bootstrap-star-rating/themes/krajee-svg/theme.css">


    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/book.css">
    
    <script src="js/jquery-3.1.0.min.js"></script>

  </head>

  <body>
  
    <?php 
      include('header.php');
    ?>
    <!-- /header -->
    <div class="menu-wrap container-fluid">
      <nav class="menu clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php">Liên Hệ</a></li>
          </ul>
</nav>
      <a href="index.php" class="toggle-menu"><i class="fa fa-bars" aria-hidden="true"></i></a>
      <nav class="menu-mobile clearfix">
          <ul class="main-menu clearfix">
              <li><a href="index.php">Trang chủ</a></li>
              <li>
                  <a href="category-qua-hopqua.php">Quà HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-qua-hopqua.php">Hộp Quà</a></li>
                      <li><a href="category-qua-thiep.php">Thiệp</a></li>
                  </ul>
              </li>
              <li>
                  <a href="category-phukien-daychuyen.php">Phụ kiện HandMade <span class="arrow">&#9660;</span></a>
   
                  <ul class="sub-menu">
                      <li><a href="category-phukien-daychuyen.php">Dây Chuyền</a></li>
                      <li><a href="category-phukien-vongtay.php">Vòng tay</a></li>
                      <li><a href="category-phukien-dongho.php">Đồng Hồ</a></li>
                      <li><a href="category-phukien-mockhoa.php">Móc Khóa</a></li>
                  </ul>
              </li>
              <li><a href="category-khuyenmai.php">Khuyến Mãi</a></li>
              <li><a href="contact.php">Liên Hệ</a></li>
          </ul>
      </nav>
    </div>
    <?php 
      $cus_id = $_SESSION['user_id']; 
      $stmt_customer_info = $conn->prepare("SELECT * FROM customer                                 
                                              WHERE customer.id='$cus_id'");
      $stmt_customer_info->setFetchMode(PDO::FETCH_ASSOC);
      $stmt_customer_info->execute();
              $row = $stmt_customer_info->fetch();
              $autofill_name = $row['fullname'];
              $autofill_email = $row['email'];
              $autofill_phone = $row['phonenumber'];
              $autofill_address = $row['address'];
            
    ?>
    <div class="content container">
      <div class="left-side col-lg-5 col-md-5 col-sm-6 col-xs-12">
        <div class="content-left-side">
          <div class="con-tit">
          <span class="tit">Thông tin giao hàng</span>
          </div>
          <form action="book.php" method="POST">
            <label>Tên người nhận: </label><br>
            <input value="<?php  echo $autofill_name;?>" type="text" name="name" required class="form-control"><br>
            <label>Số điện thoại: </label><br>
            <input value="<?php  echo $autofill_phone;?>" type="text" name="phone" required class="form-control"><br>
            <label>Email: </label><br>
            <input value="<?php  echo $autofill_email;?>" type="email" name="email" class="form-control" required><br>
            <label>Địa chỉ nhân hàng:</label><br>
            <input type="text" value="<?php  echo $autofill_address;?>" name="address" class="form-control">
            <button type="submit" class="btn btn-success" name="order-btn">Đặt hàng</button>
          </form>

        </div>
      </div>
      <div class="right-side col-lg-7 col-md-7 col-sm-6 col-xs-12">
        <div class="content-right-side">
          <div class="con-tit">
          <span class="tit">Đơn hàng</span>
          <a href="cart.php" class="btn btn-primary">Sửa</a>
          </div>
          
          <?php 
            $cus_id = $_SESSION['user_id'];
            $stmt_cart_info = $conn->prepare("SELECT cart.cart_id, product.id, product.name, product.gia, product.link_anh, product.giamgia, cart.soluong 
                                              FROM cart 
                                              INNER JOIN customer ON cart.customer_id = customer.id
                                              INNER JOIN product ON cart.product_id = product.id
                                              WHERE customer.id='$cus_id'");
            $stmt_cart_info->setFetchMode(PDO::FETCH_ASSOC);
            $stmt_cart_info->execute();

            $total_val = 0;

            while($row = $stmt_cart_info->fetch()) {
              $subprice = $row['gia'] - $row['giamgia'];
              $total_val += $row['soluong']*$subprice;
          ?>

          <div class="for-one clearfix">
            <div class="left-name col-lg-6 col-md-6 col-sm-6 col-xs-6">
              <span class="name"><?php echo $row['name']; ?></span>
            </div>
            <div class="right-price col-lg-4 col-md-4 col-sm-4 col-xs-4">
              <span class="price"><?php echo $subprice; ?></span><span> 000đ</span>
            </div>
            <div class="center-num col-lg-2 col-md-2 col-sm-2 col-xs-2">
              <span class="num">x <?php echo $row['soluong']; ?></span>
            </div>
          </div>
          <?php } ?>
          
         
          <div class="for-total clearfix">
            <div class="left-name col-lg-6 col-md-6 col-sm-6 col-xs-6">
              <span class="total"> Tổng:</span>
            </div>
            <div class="center-num col-lg-2 col-md-2 col-sm-2 col-xs-2">
              
            </div>
            <div class="right-price col-lg-4 col-md-4 col-sm-4 col-xs-4">
              <span class="pricesum"><?php echo $total_val; ?> 000</span><span> đ</span>
            </div>
          </div>

        </div>        
      </div>
    </div>
    


      <?php 
        if (isset($_POST['order-btn'])) {
          try {
            $stmt_customer_info = $conn->prepare("SELECT customer.name, customer.email, customer.phone, customer.address
                                              FROM customer                                 
                                              WHERE customer.id='$cus_id'");
            while ($row = $stmt_customer_info->fetch()) {
              $autofill_name = $row['name'];
              $autofill_email = $row['email'];
              $autofill_phone = $row['phone'];
              $autofill_address = $row['address'];
            }

            $stmt_insert_transaction = $conn->prepare("INSERT INTO transaction (customer_id, customer_name, customer_phone, customer_email, customer_address, amount, date_added) VALUES (:customer_id, :customer_name, :customer_phone, :customer_email, :customer_address, :amount, :date_added)");
            $stmt_insert_transaction->bindParam(':customer_id', $cus_id);
            $stmt_insert_transaction->bindParam(':customer_name', $_POST['name']);
            $stmt_insert_transaction->bindParam(':customer_phone', $_POST['phone']);
            $stmt_insert_transaction->bindParam(':customer_email', $_POST['email']);
            $stmt_insert_transaction->bindParam(':customer_address', $_POST['address']);
            $stmt_insert_transaction->bindParam(':amount', $total_val);
            $stmt_insert_transaction->bindParam(':date_added', date("Y-m-d h:i:sa"));

            $stmt_insert_transaction->execute();
            
            $stmt_transaction_lastID = $conn->prepare('SELECT * FROM transaction ORDER BY id DESC');
            $stmt_transaction_lastID->setFetchMode(PDO::FETCH_ASSOC);
            $stmt_transaction_lastID->execute();
            $lastTranID = $stmt_transaction_lastID->fetchColumn();


            $stmt_insert_order = $conn->prepare("INSERT INTO order_product (transaction_id, product_id, soluong, gia, tongtien) VALUES (:transaction_id, :product_id, :soluong, :gia, :tongtien)");
            $stmt_cart = $conn->prepare("SELECT product.id, product.gia, product.giamgia, cart.soluong 
                                              FROM cart 
                                              INNER JOIN customer ON cart.customer_id = customer.id
                                              INNER JOIN product ON cart.product_id = product.id
                                              WHERE customer.id='$cus_id'");
            $stmt_cart->setFetchMode(PDO::FETCH_ASSOC);
            $stmt_cart->execute();
            while($row = $stmt_cart->fetch()) {
              $subprice = $row['gia'] - $row['giamgia'];
              $tongtien = $subprice*$row['soluong'];
              $stmt_insert_order->bindParam(':transaction_id', $lastTranID);
              $stmt_insert_order->bindParam(':product_id', $row['id']);
              $stmt_insert_order->bindParam(':soluong', $row['soluong']);
              $stmt_insert_order->bindParam(':gia', $subprice);
              $stmt_insert_order->bindParam(':tongtien', $tongtien);
              $stmt_insert_order->execute();
            }

            // header('Location: index.php');
            // echo "<div class='alert alert-success order-success'>
            //   <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
            //   <strong>Chúc mừng!</strong> Bạn đã đặt hàng thành công!
            // </div>";

            echo "<script>
                  window.location.replace('index.php');
                  alert('Chúc mừng bạn đã đặt hàng thành công!');
                
            </script>";
           
          }
          catch (PDOException $e) {
            echo "ERROR! Co loi xay ra voi PDO";
            echo $e->getMessage();
            exit();
          } 

        }
      ?>

  <?php 
    include('footer.php');
  ?>

  <!-- Script -->
    
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="Swiper-3.3.1/dist/js/swiper.min.js"></script>
    <script src="bootstrap-star-rating/js/star-rating.js"></script>
    <script src="bootstrap-star-rating/themes/krajee-svg/theme.js"></script>
    <script src="bootstrap-star-rating/js/locales/LANG.js"></script>

    <script src="js/main.js"></script>
    
    
    <script>
      $(".toggle-menu").click(function(){
        $(".menu-mobile").toggle();
      });

      var swiper = new Swiper('.swiper-container', {
          pagination: '.swiper-pagination',
          nextButton: '.swiper-button-next',
          prevButton: '.swiper-button-prev',
          paginationClickable: true,
          spaceBetween: 30,
          centeredSlides: true,
          autoplay: 2500,
          loop: true,
          autoplayDisableOnInteraction: false
      });
    </script>

   
    <script type="text/javascript">
      $(function() 
      {
    //----- OPEN
    $('[data-popup-open]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
 
        e.preventDefault();
      });
 
    //----- CLOSE
    $('[data-popup-close]').on('click', function(e)  
      {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
 
        e.preventDefault();
      });
    });
      $(document).mouseup(function (e) 
      {
        if ($('.popup').is(e.target))
            {
               $(".popup").fadeOut(350);
           }
      });



      $("a[href='#top']").click(function() {
         $("html, body").animate({ scrollTop: 0 }, "slow");
         return false;
      });

      $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#go-top').fadeIn();
        } else {
            $('#go-top').fadeOut();
        }
      });

      $("#input-id").rating({starCaptions:{}});

     </script>
  </body>
</html>







